﻿Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports System.IO
Public Class AssetFolderObject
    Public Property Path As String
    Public Property Name As String
    Public Property ObjectPath As String
    Public Property DataPath As String
    Public Property TagFile As String
End Class
Module TagInfoModule
    Public Function GetTagsFromJSON(TagFile As String)
        Dim rawJson = File.ReadAllText(TagFile)
        Dim TagObject = JsonConvert.DeserializeObject(rawJson)
        Return TagObject
    End Function

    Public Function GetTagsFromSubfolders(AssetFolderName As String, Source As String)
        Dim ObjectPath As String = Source & "\textures\objects"
        '
        ' 8/5/2020 - Added by Noral
        ' Fixed initialization issue
        '
        Dim ColorablePath As String = ""

        'Get the exact, case-sensitive path name for the textures\objects\colorable folder.
        Dim ColorablePathArray = From subfolder In My.Computer.FileSystem.GetDirectories(ObjectPath.ToString())
                                 Where (My.Computer.FileSystem.GetDirectoryInfo(subfolder)).Name.ToLower() = "colorable"
        For Each path As String In ColorablePathArray
            ColorablePath = path
        Next

        'Set the values for the main keys that will appear in the JSON file.
        Dim tags As String = "tags"
        Dim colorable As String = "Colorable"
        Dim sets As String = "sets"

        'Set up ordered dictionaries that we can later serialize for later covnersion to JSON.
        Dim TagObject As New System.Collections.Specialized.OrderedDictionary
        Dim FolderObject As New System.Collections.Specialized.OrderedDictionary
        Dim ColorableObject As New System.Collections.Specialized.OrderedDictionary
        Dim SetObject As New System.Collections.Specialized.OrderedDictionary
        '
        ' 8/5/2020 - Added by Noral
        ' Commented out since not used
        '
        'Dim TagSetMembers() As String

        'Get a recursive list of subfolders in textures\objects.
        Dim SubFolders As String() = Directory.GetDirectories(ObjectPath, "*.*", SearchOption.AllDirectories)

        'For each subfolder, split the path into substrings, and take the last value as the folder name to use as the tag.
        For i = 0 To SubFolders.Count - 1
            If SubFolders(i).Split("\").Count <> 0 Then SubFolders(i) = SubFolders(i).Split("\")(SubFolders(i).Split("\").Count - 1)
        Next

        'Eliminate duplicate folder names.
        Dim UniqueFolders = SubFolders.Distinct().ToArray

        'Sort the list alphabetically.
        Array.Sort(UniqueFolders)

        'Add the list of folders to the tag set.
        SetObject.Add(AssetFolderName, UniqueFolders)

        'Get the list files from the root of textures\objects and textures\objects\colorable.
        Dim RootFiles As String() = Directory.GetFiles(ObjectPath)
        Dim RootColorableFiles As String()

        If Directory.Exists(ColorablePath) Then
            RootColorableFiles = Directory.GetFiles(ColorablePath)
            ReDim Preserve RootFiles(RootFiles.Count + RootColorableFiles.Count - 1)
            RootColorableFiles.CopyTo(RootFiles, RootFiles.Count - RootColorableFiles.Count)
        End If

        'For each file, truncate the path up to "textures" so we're left with "textures\objects\<filename>".
        'Then replace the backslashes with forward slashes so we're left with "textures/objects/<filename>".
        For i = 0 To RootFiles.Count - 1
            RootFiles(i) = RootFiles(i).Replace(Source & "\", "")
            RootFiles(i) = RootFiles(i).Replace("\", "/")
        Next

        Array.Sort(RootFiles)

        'If a textures\objects\colorable folder exists, get the list of files from textures\objects\colorable.
        '
        ' 8/5/2020 - Added by Noral
        ' Fixed initialization issue
        '

        'Get a recursive list of all files in all subfolders under textures\objects.
        Dim AllObjects As String() = Directory.GetFiles(ObjectPath, "*.*", SearchOption.AllDirectories)

        'For each file, truncate the path up to "textures" so we're left with "textures\objects\<path>\<filename>".
        'Then replace the backslashes with forward slashes so we're left with "textures/objects/<path>/<filename>".
        For i = 0 To AllObjects.Count - 1
            AllObjects(i) = AllObjects(i).Replace(Source & "\", "")
            AllObjects(i) = AllObjects(i).Replace("\", "/")
        Next

        'For each subfolder, add the folder and its associated files to the FolderObject ordered dictionary.
        'Each subfolder name is what will be considered a Tag, and each file contained within that subfolder 
        'will be associated with its parent folder names as tags.
        For Each folder As String In UniqueFolders
            Dim folderset As String() = Array.FindAll(AllObjects, Function(s) s.Contains("/" & folder & "/"))
            Array.Sort(folderset)
            FolderObject.Add(folder, folderset)
        Next

        'Add the FolderObject ordered dictionary to the TagObject ordered dictionary.
        TagObject.Add(tags, FolderObject)

        'Add the SetObject ordered dictionary to the TagObject ordered dictionary.
        TagObject.Add(sets, SetObject)

        'Convert the TagObject ordered dictionary to a JSON-formatted string.
        Dim JSONString As String = JsonConvert.SerializeObject(TagObject, Formatting.Indented)
        Dim TagJSON = JsonConvert.DeserializeObject(JSONString)

        Return TagJSON
    End Function

    Public Function BuildTagsFromScratch()
        Dim AssetTagArray() As String = {"Administration", "Armor", "Bar", "Barrel", "Bed", "Blacksmith", "Blood", "Boat", "Bridge", "Broken", "Bush", "Cage",
            "Camp", "Cart", "Cave", "Chair", "Clutter", "Cobweb", "Colorable", "Corpse", "Crate", "Creature", "Decor", "Desk", "Dining", "Fixture", "Floating",
            "Food", "Fountain", "Grave", "Horse", "Lighting", "Magic", "Mine", "Mushroom", "Obstacle", "Pillar", "Plant", "Rock", "Rug", "Sack", "Sewers", "Ship",
            "Skeleton", "Snow", "Stable", "Stairs", "Statue", "Storage", "Structure", "Table", "Thorn", "Tool", "Trap", "Treasure", "Tree", "Water", "Weapon", "Wood"}
        Dim tags As String = "tags"
        Dim sets As String = "sets"

        Dim NewTagInfo As New System.Collections.Specialized.OrderedDictionary
        Dim NewTagObject As New System.Collections.Specialized.OrderedDictionary
        Dim EmptyList As New List(Of String)
        For Each AssetTag In AssetTagArray
            NewTagObject.Add(AssetTag, EmptyList)
        Next
        NewTagInfo.Add(tags, NewTagObject)

        Dim NewSetObject As New System.Collections.Specialized.OrderedDictionary
        Dim CombatSet As New List(Of String) From {
            "Armor",
            "Blood",
            "Broken",
            "Corpse",
            "Magic",
            "Skeleton",
            "Trap",
            "Weapon"
        }
        NewSetObject.Add("Combat", CombatSet)

        Dim ContainerSet As New List(Of String) From {
            "Barrel",
            "Crate",
            "Storage"
        }
        NewSetObject.Add("Containers", ContainerSet)

        Dim CraftsTradesSet As New List(Of String) From {
            "Administration",
            "Barrel",
            "Blacksmith",
            "Cart",
            "Chair",
            "Crate",
            "Desk",
            "Fixture",
            "Lighting",
            "Mine",
            "Stable",
            "Table",
            "Wood"
        }
        NewSetObject.Add("Crafts & Trades", CraftsTradesSet)

        Dim DungeonSet As New List(Of String) From {
            "Armor",
            "Barrel",
            "Blood",
            "Cage",
            "Cobweb",
            "Crate",
            "Magic",
            "Obstacle",
            "Pillar",
            "Skeleton",
            "Stairs",
            "Statue",
            "Trap",
            "Treasure"
        }
        NewSetObject.Add("Dungeon", DungeonSet)

        Dim EncampmentSet As New List(Of String) From {
            "Bush",
            "Camp",
            "Cart",
            "Floating",
            "Wood"
        }
        NewSetObject.Add("Encapment", EncampmentSet)

        Dim FurnitureSet As New List(Of String) From {
            "Bed",
            "Chair",
            "Desk",
            "Fixture",
            "Rug",
            "Table"
        }
        NewSetObject.Add("Furniture", FurnitureSet)

        Dim LivingQuartersSet As New List(Of String) From {
            "Bed",
            "Chair",
            "Clutter",
            "Decor",
            "Desk",
            "Fixture",
            "Rug",
            "Storage",
            "Table"
        }
        NewSetObject.Add("Living Quarters", LivingQuartersSet)

        Dim MessHallSet As New List(Of String) From {
            "Chair",
            "Decor",
            "Dining",
            "Lighting",
            "Pillar",
            "Rug",
            "Table"
        }
        NewSetObject.Add("Mess Hall", MessHallSet)

        Dim MilitarySet As New List(Of String) From {
            "Armor",
            "Blood",
            "Corpse",
            "Horse",
            "Trap",
            "Weapon"
        }
        NewSetObject.Add("Military", MilitarySet)

        Dim NatureSet As New List(Of String) From {
            "Bush",
            "Cobweb",
            "Creature",
            "Mushroom",
            "Plant",
            "Rock",
            "Thorn",
            "Tree",
            "Water"
        }
        NewSetObject.Add("Nature", NatureSet)

        Dim OfficeSet As New List(Of String) From {
            "Administration",
            "Chair",
            "Decor",
            "Desk",
            "Rug",
            "Table"
        }
        NewSetObject.Add("Office", OfficeSet)

        Dim TavernSet As New List(Of String) From {
            "Bar",
            "Barrel",
            "Bed",
            "Chair",
            "Crate",
            "Decor",
            "Desk",
            "Dining",
            "Fixture",
            "Food",
            "Rug",
            "Sack",
            "Stable",
            "Stairs",
            "Table",
            "Wood"
        }
        NewSetObject.Add("Tavern", TavernSet)

        Dim TownSet As New List(Of String) From {
            "Bridge",
            "Bush",
            "Cart",
            "Fountain",
            "Grave",
            "Lighting",
            "Structure"
        }
        NewSetObject.Add("Town", TownSet)

        Dim WaterSet As New List(Of String) From {
            "Boat",
            "Bridge",
            "Floating",
            "Fountain",
            "Ship",
            "Snow",
            "Water"
        }
        NewSetObject.Add("Water", WaterSet)

        NewTagInfo.Add(sets, NewSetObject)

        Dim JSONString As String = JsonConvert.SerializeObject(NewTagInfo, Formatting.Indented)
        Dim TagJSON = JsonConvert.DeserializeObject(JSONString)
        Return TagJSON
    End Function

    Public Function SortTagInfo(TagObject As JObject)
        Dim SortedTagInfo As New System.Collections.Specialized.OrderedDictionary
        Dim SortedTagObject As New System.Collections.Specialized.OrderedDictionary
        Dim SortedSetObject As New System.Collections.Specialized.OrderedDictionary
        SortedTagInfo.Add("tags", SortedTagObject)
        SortedTagInfo.Add("sets", SortedSetObject)

        Dim UnsortedTagList As JObject = TagObject("tags")
        Dim SortedTagList As New List(Of String)
        For Each UnsortedTag In UnsortedTagList
            SortedTagList.Add(UnsortedTag.Key)
        Next

        SortedTagList.Sort()

        For Each SortedTag In SortedTagList
            Dim SortedAssetList As New List(Of String)
            For Each UnsortedTag In UnsortedTagList
                If SortedTag = UnsortedTag.Key Then
                    For Each UnsortedAsset In UnsortedTag.Value
                        SortedAssetList.Add(UnsortedAsset)
                    Next
                    Exit For
                End If
            Next
            SortedAssetList.Sort()
            SortedTagObject.Add(SortedTag, SortedAssetList)
        Next

        Dim UnsortedSetList As JObject = TagObject("sets")
        Dim SortedSetList As New List(Of String)
        For Each UnsortedSet In UnsortedSetList
            SortedSetList.Add(UnsortedSet.Key)
        Next
        SortedSetList.Sort()

        For Each SortedSet In SortedSetList
            Dim SortedSetTags As New List(Of String)
            For Each UnsortedSet In UnsortedSetList
                If SortedSet = UnsortedSet.Key Then
                    For Each UnsortedSetTag In UnsortedSet.Value
                        SortedSetTags.Add(UnsortedSetTag)
                    Next
                    Exit For
                End If
            Next
            SortedSetTags.Sort()
            SortedSetObject.Add(SortedSet, SortedSetTags)
        Next

        Dim JSONString As String = JsonConvert.SerializeObject(SortedTagInfo, Formatting.Indented)
        Dim TagJSON = JsonConvert.DeserializeObject(JSONString)

        Return TagJSON
    End Function

    Public Function SortTemplateInfo(TagObject As JObject)
        Dim SortedTagInfo As New System.Collections.Specialized.OrderedDictionary
        Dim SortedTagObject As New System.Collections.Specialized.OrderedDictionary
        Dim SortedSetObject As New System.Collections.Specialized.OrderedDictionary
        SortedTagInfo.Add("tags", SortedTagObject)
        SortedTagInfo.Add("sets", SortedSetObject)

        Dim UnsortedTagList As JObject = TagObject("tags")
        Dim SortedTagList As New List(Of String)
        For Each UnsortedTag In UnsortedTagList
            If UnsortedTag.Key.ToLower <> "colorable" Then SortedTagList.Add(UnsortedTag.Key)
        Next

        SortedTagList.Sort()

        For Each UnsortedTag In UnsortedTagList
            If UnsortedTag.Key.ToLower = "colorable" Then SortedTagList.Add(UnsortedTag.Key)
        Next

        Dim EmptyList As New List(Of String)
        For Each SortedTag In SortedTagList
            SortedTagObject.Add(SortedTag, EmptyList)
        Next

        Dim UnsortedSetList As JObject = TagObject("sets")
        Dim SortedSetList As New List(Of String)
        For Each UnsortedSet In UnsortedSetList
            SortedSetList.Add(UnsortedSet.Key)
        Next
        SortedSetList.Sort()

        For Each SortedSet In SortedSetList
            Dim SortedSetTags As New List(Of String)
            For Each UnsortedSet In UnsortedSetList
                If SortedSet = UnsortedSet.Key Then
                    For Each UnsortedSetTag In UnsortedSet.Value
                        SortedSetTags.Add(UnsortedSetTag)
                    Next
                    Exit For
                End If
            Next
            SortedSetTags.Sort()
            SortedSetObject.Add(SortedSet, SortedSetTags)
        Next

        Dim JSONString As String = JsonConvert.SerializeObject(SortedTagInfo, Formatting.Indented)
        Dim TagJSON = JsonConvert.DeserializeObject(JSONString)

        Return TagJSON
    End Function

    Public Function GetTagInfo(Source As String)
        Dim IsFolderNameValid As Boolean
        Dim DoesFolderExist As Boolean
        'Dim TagObject As Object = vbNull
        Dim TagObject As New Newtonsoft.Json.Linq.JObject

        IsFolderNameValid = IsValidPathName(Source)
        DoesFolderExist = Directory.Exists(Source)
        If IsFolderNameValid And DoesFolderExist Then
            Dim AssetFolder As New AssetFolderObject
            AssetFolder.Path = Source
            AssetFolder.Name = My.Computer.FileSystem.GetDirectoryInfo(Source).Name
            AssetFolder.ObjectPath = Source & "\textures\objects"
            AssetFolder.DataPath = Source & "\data"
            AssetFolder.TagFile = AssetFolder.DataPath & "\default.dungeondraft_tags"

            Dim SubFolders = Directory.GetDirectories(AssetFolder.ObjectPath)
            If File.Exists(AssetFolder.TagFile) Then
                TagObject = GetTagsFromJSON(AssetFolder.TagFile)
            ElseIf Directory.Exists(AssetFolder.ObjectPath) And SubFolders.Count >= 1 Then
                TagObject = GetTagsFromSubfolders(AssetFolder.Name, AssetFolder.Path)
            Else
                Dim Tags As New JObject
                Dim Sets As New JObject
                TagObject.Add("tags", Tags)
                TagObject.Add("sets", Sets)
            End If
        End If
        Return TagObject
    End Function
End Module
