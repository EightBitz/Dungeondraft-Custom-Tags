﻿Imports System.IO
Imports System.Environment
Module CopyConfigModule
    Public Sub CopyConfig()
        Dim OldConfigFolder As String = GetFolderPath(SpecialFolder.ApplicationData) & "\Custom Tags"
        Dim NewConfigFolder As String = GetFolderPath(SpecialFolder.ApplicationData) & "\EightBitz\Custom Tags"
        Dim ConfigFile As String = "CustomTags.config"

        Dim OldConfigFile As String = OldConfigFolder & "\" & ConfigFile
        Dim NewConfigFile As String = NewConfigFolder & "\" & ConfigFile

        If File.Exists(OldConfigFile) And Not File.Exists(NewConfigFile) Then
            If Not Directory.Exists(NewConfigFolder) Then Directory.CreateDirectory(NewConfigFolder)
            File.Copy(OldConfigFile, NewConfigFile)

            If File.Exists(OldConfigFile) And File.Exists(NewConfigFile) Then
                File.Delete(OldConfigFile)
                Directory.Delete(OldConfigFolder)
            End If
        End If

    End Sub
End Module
