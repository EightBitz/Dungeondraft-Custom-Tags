﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DDToolsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DDToolsForm))
        Me.MainMenuStrip = New System.Windows.Forms.MenuStrip()
        Me.MainMenuToolStripMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.TagAssetsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColorThemeMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColorThemeApplyToMapMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColorThemeCreateFromMapMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConvertAssetsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConvertPacksMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyAssetsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyTilesMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataFilesMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MapDetailsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PackAssetsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnpackAssetsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PreferencesToolStripMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadPrefsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SavePrefsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DocumentationMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LicenseMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.READMEMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConvertPacksGroupBox = New System.Windows.Forms.GroupBox()
        Me.ConvertPacksSelectAllCheckBox = New System.Windows.Forms.CheckBox()
        Me.ConvertPacksLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.ConvertPacksStartButton = New System.Windows.Forms.Button()
        Me.ConvertPacksSelectNoneButton = New System.Windows.Forms.Button()
        Me.ConvertPacksSelectAllButton = New System.Windows.Forms.Button()
        Me.ConvertPacksCheckedListBox = New System.Windows.Forms.CheckedListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ConvertPacksCleanUpCheckBox = New System.Windows.Forms.CheckBox()
        Me.ConvertPacksDestinationTextBox = New System.Windows.Forms.TextBox()
        Me.ConvertPacksSourceTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ConvertPacksDestinationBrowseButton = New System.Windows.Forms.Button()
        Me.ConvertPacksSourceBrowseButton = New System.Windows.Forms.Button()
        Me.TagAssetsGroupBox = New System.Windows.Forms.GroupBox()
        Me.TagAssetsSelectAllCheckBox = New System.Windows.Forms.CheckBox()
        Me.TagAssetsLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.TagAssetsStartButton = New System.Windows.Forms.Button()
        Me.TagAssetsSelectNoneButton = New System.Windows.Forms.Button()
        Me.TagAssetsSelectAllButton = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TagAssetsCheckedListBox = New System.Windows.Forms.CheckedListBox()
        Me.TagAssetsDefaultTagTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TagAssetsSourceTextBox = New System.Windows.Forms.TextBox()
        Me.TagAssetsBrowseButton = New System.Windows.Forms.Button()
        Me.ConvertPacksSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.ConvertPacksDestinationBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.TagAssetsSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.CopyAssetsGroupBox = New System.Windows.Forms.GroupBox()
        Me.CopyAssetsSelectAllCheckBox = New System.Windows.Forms.CheckBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.CopyAssetsSelectNoneButton = New System.Windows.Forms.Button()
        Me.CopyAssetsSelectAllButton = New System.Windows.Forms.Button()
        Me.CopyAssetsCheckedListBox = New System.Windows.Forms.CheckedListBox()
        Me.CopyAssetsLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.CopyAssetsPortalsCheckBox = New System.Windows.Forms.CheckBox()
        Me.CopyAssetsCreateTagsCheckBox = New System.Windows.Forms.CheckBox()
        Me.CopyAssetsSourceTextBox = New System.Windows.Forms.TextBox()
        Me.CopyAssetsDestinationTextBox = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CopyAssetsStartButton = New System.Windows.Forms.Button()
        Me.CopyAssetsDestinationBrowseButton = New System.Windows.Forms.Button()
        Me.CopyAssetsSourceBrowseButton = New System.Windows.Forms.Button()
        Me.CopyAssetsSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.CopyAssetsDestinationBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.ConvertAssetsGroupBox = New System.Windows.Forms.GroupBox()
        Me.ConvertAssetsSelectAllCheckBox = New System.Windows.Forms.CheckBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.ConvertAssetsSelectNoneButton = New System.Windows.Forms.Button()
        Me.ConvertAssetsSelectAllButton = New System.Windows.Forms.Button()
        Me.ConvertAssetsCheckedListBox = New System.Windows.Forms.CheckedListBox()
        Me.ConvertAssetsLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ConvertAssetsSourceTextBox = New System.Windows.Forms.TextBox()
        Me.ConvertAssetsDestinationTextBox = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ConvertAssetsStartButton = New System.Windows.Forms.Button()
        Me.ConvertAssetsDestinationBrowseButton = New System.Windows.Forms.Button()
        Me.ConvertAssetsSourceBrowseButton = New System.Windows.Forms.Button()
        Me.ConvertAssetsSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.ConvertAssetsDestinationBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.TitlePanel = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.VersionLabel = New System.Windows.Forms.Label()
        Me.CreativeCommonsLinkLabel = New System.Windows.Forms.LinkLabel()
        Me.GitHubLinkLabel = New System.Windows.Forms.LinkLabel()
        Me.EmailLinkLabel = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.UnpackAssetsGroupBox = New System.Windows.Forms.GroupBox()
        Me.UnpackAssetsSelectAllCheckBox = New System.Windows.Forms.CheckBox()
        Me.UnpackAssetsLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.UnpackAssetsStartButton = New System.Windows.Forms.Button()
        Me.UnpackAssetsSelectNoneButton = New System.Windows.Forms.Button()
        Me.UnpackAssetsSelectAllButton = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.UnpackAssetsCheckedListBox = New System.Windows.Forms.CheckedListBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.UnpackAssetsSourceTextBox = New System.Windows.Forms.TextBox()
        Me.UnpackAssetsDestinationTextBox = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.UnpackAssetsDestinationBrowseButton = New System.Windows.Forms.Button()
        Me.UnpackAssetsSourceBrowseButton = New System.Windows.Forms.Button()
        Me.UnpackAssetsSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.UnpackAssetsDestinationBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.PackAssetsSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.PackAssetsDestinationBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.PackAssetsGroupBox = New System.Windows.Forms.GroupBox()
        Me.PackAssetsSelectAllCheckBox = New System.Windows.Forms.CheckBox()
        Me.PackAssetsOverwriteCheckBox = New System.Windows.Forms.CheckBox()
        Me.PackAssetsRefreshButton = New System.Windows.Forms.Button()
        Me.PackAssetsLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.PackAssetsDataGridView = New System.Windows.Forms.DataGridView()
        Me.PackAssetsStartButton = New System.Windows.Forms.Button()
        Me.PackAssetsSelectNoneButton = New System.Windows.Forms.Button()
        Me.PackAssetsSelectAllButton = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.PackAssetsSourceTextBox = New System.Windows.Forms.TextBox()
        Me.PackAssetsDestinationTextBox = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.PackAssetsDestinationBrowseButton = New System.Windows.Forms.Button()
        Me.PackAssetsSourceBrowseButton = New System.Windows.Forms.Button()
        Me.CopyTilesGroupBox = New System.Windows.Forms.GroupBox()
        Me.CopyTilesSelectAllCheckBox = New System.Windows.Forms.CheckBox()
        Me.CopyTilesDataGridView = New System.Windows.Forms.DataGridView()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.CopyTilesLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.CopyTilesSourceTextBox = New System.Windows.Forms.TextBox()
        Me.CopyTilesDestinationTextBox = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.CopyTilesStartButton = New System.Windows.Forms.Button()
        Me.CopyTilesDestinationBrowseButton = New System.Windows.Forms.Button()
        Me.CopyTilesSourceBrowseButton = New System.Windows.Forms.Button()
        Me.CopyTilesSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.CopyTilesDestinationBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.MapDetailsGroupBox = New System.Windows.Forms.GroupBox()
        Me.MapDetailsSelectAllCheckBox = New System.Windows.Forms.CheckBox()
        Me.MapDetailsLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.MapDetailsStartButton = New System.Windows.Forms.Button()
        Me.MapDetailsSelectNoneButton = New System.Windows.Forms.Button()
        Me.MapDetailsSelectAllButton = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.MapDetailsCheckedListBox = New System.Windows.Forms.CheckedListBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.MapDetailsSourceTextBox = New System.Windows.Forms.TextBox()
        Me.MapDetailsBrowseButton = New System.Windows.Forms.Button()
        Me.MapDetailsSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.DataFilesGroupBox = New System.Windows.Forms.GroupBox()
        Me.DataFilesDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataFilesLogCheckBox = New System.Windows.Forms.CheckBox()
        Me.DataFilesSourceTextBox = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.DataFilesStartButton = New System.Windows.Forms.Button()
        Me.DataFilesSourceBrowseButton = New System.Windows.Forms.Button()
        Me.DataFilesSourceBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.DataFilesColorDialog = New System.Windows.Forms.ColorDialog()
        Me.ColorThemeApplyGroupBox = New System.Windows.Forms.GroupBox()
        Me.ApplyColorThemeBackupPalettesCheckBox = New System.Windows.Forms.CheckBox()
        Me.ApplyColorThemeMapListBox = New System.Windows.Forms.ListBox()
        Me.ApplyColorThemeColorThemeListBox = New System.Windows.Forms.ListBox()
        Me.ApplyColorThemeStartButton = New System.Windows.Forms.Button()
        Me.ApplyColorThemeColorThemeFolderTextBox = New System.Windows.Forms.TextBox()
        Me.ApplyColorThemeMapFolderTextBox = New System.Windows.Forms.TextBox()
        Me.ApplyColorThemeMapFolderBrowseButton = New System.Windows.Forms.Button()
        Me.ApplyColorThemeColorThemeFolderBrowseButton = New System.Windows.Forms.Button()
        Me.ColorThemeCreateGroupBox = New System.Windows.Forms.GroupBox()
        Me.CreateColorThemeIncludeNonPaletteColorsCheckBox = New System.Windows.Forms.CheckBox()
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox = New System.Windows.Forms.CheckBox()
        Me.CreateColorThemeStartButton = New System.Windows.Forms.Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.CreateColorThemeSourceMapTextBox = New System.Windows.Forms.TextBox()
        Me.CreateColorThemeColorThemeTextBox = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.CreateColorThemeSaveButton = New System.Windows.Forms.Button()
        Me.CreateColorThemeSourceMapOpenButton = New System.Windows.Forms.Button()
        Me.CreateColorThemeOpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.CreateColorThemeSaveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.ApplyColorThemeThemeFolderBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.ApplyColorThemeMapFolderBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.MainMenuStrip.SuspendLayout()
        Me.ConvertPacksGroupBox.SuspendLayout()
        Me.TagAssetsGroupBox.SuspendLayout()
        Me.CopyAssetsGroupBox.SuspendLayout()
        Me.ConvertAssetsGroupBox.SuspendLayout()
        Me.TitlePanel.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UnpackAssetsGroupBox.SuspendLayout()
        Me.PackAssetsGroupBox.SuspendLayout()
        CType(Me.PackAssetsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CopyTilesGroupBox.SuspendLayout()
        CType(Me.CopyTilesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MapDetailsGroupBox.SuspendLayout()
        Me.DataFilesGroupBox.SuspendLayout()
        CType(Me.DataFilesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ColorThemeApplyGroupBox.SuspendLayout()
        Me.ColorThemeCreateGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainMenuStrip
        '
        Me.MainMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MainMenuToolStripMenu, Me.PreferencesToolStripMenu, Me.HelpToolStripMenuItem})
        Me.MainMenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MainMenuStrip.Name = "MainMenuStrip"
        Me.MainMenuStrip.Size = New System.Drawing.Size(1012, 24)
        Me.MainMenuStrip.TabIndex = 0
        Me.MainMenuStrip.Text = "Main Menu"
        '
        'MainMenuToolStripMenu
        '
        Me.MainMenuToolStripMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TagAssetsMenuItem, Me.ColorThemeMenuItem, Me.ConvertAssetsMenuItem, Me.ConvertPacksMenuItem, Me.CopyAssetsMenuItem, Me.CopyTilesMenuItem, Me.DataFilesMenuItem, Me.MapDetailsMenuItem, Me.PackAssetsMenuItem, Me.UnpackAssetsMenuItem})
        Me.MainMenuToolStripMenu.Name = "MainMenuToolStripMenu"
        Me.MainMenuToolStripMenu.Size = New System.Drawing.Size(80, 20)
        Me.MainMenuToolStripMenu.Text = "Main Menu"
        '
        'TagAssetsMenuItem
        '
        Me.TagAssetsMenuItem.Name = "TagAssetsMenuItem"
        Me.TagAssetsMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.TagAssetsMenuItem.Text = "Tag Assets"
        '
        'ColorThemeMenuItem
        '
        Me.ColorThemeMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ColorThemeApplyToMapMenuItem, Me.ColorThemeCreateFromMapMenuItem})
        Me.ColorThemeMenuItem.Name = "ColorThemeMenuItem"
        Me.ColorThemeMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ColorThemeMenuItem.Text = "Color Theme"
        '
        'ColorThemeApplyToMapMenuItem
        '
        Me.ColorThemeApplyToMapMenuItem.Name = "ColorThemeApplyToMapMenuItem"
        Me.ColorThemeApplyToMapMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.ColorThemeApplyToMapMenuItem.Text = "Apply Theme to Map"
        '
        'ColorThemeCreateFromMapMenuItem
        '
        Me.ColorThemeCreateFromMapMenuItem.Name = "ColorThemeCreateFromMapMenuItem"
        Me.ColorThemeCreateFromMapMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.ColorThemeCreateFromMapMenuItem.Text = "Create Theme from Map"
        '
        'ConvertAssetsMenuItem
        '
        Me.ConvertAssetsMenuItem.Name = "ConvertAssetsMenuItem"
        Me.ConvertAssetsMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ConvertAssetsMenuItem.Text = "Convert Assets"
        '
        'ConvertPacksMenuItem
        '
        Me.ConvertPacksMenuItem.Name = "ConvertPacksMenuItem"
        Me.ConvertPacksMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ConvertPacksMenuItem.Text = "Convert Packs"
        '
        'CopyAssetsMenuItem
        '
        Me.CopyAssetsMenuItem.Name = "CopyAssetsMenuItem"
        Me.CopyAssetsMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CopyAssetsMenuItem.Text = "Copy Assets"
        '
        'CopyTilesMenuItem
        '
        Me.CopyTilesMenuItem.Name = "CopyTilesMenuItem"
        Me.CopyTilesMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CopyTilesMenuItem.Text = "Copy Tiles"
        '
        'DataFilesMenuItem
        '
        Me.DataFilesMenuItem.Name = "DataFilesMenuItem"
        Me.DataFilesMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DataFilesMenuItem.Text = "Data Files"
        '
        'MapDetailsMenuItem
        '
        Me.MapDetailsMenuItem.Name = "MapDetailsMenuItem"
        Me.MapDetailsMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.MapDetailsMenuItem.Text = "Map Details"
        '
        'PackAssetsMenuItem
        '
        Me.PackAssetsMenuItem.Name = "PackAssetsMenuItem"
        Me.PackAssetsMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PackAssetsMenuItem.Text = "Pack Assets"
        '
        'UnpackAssetsMenuItem
        '
        Me.UnpackAssetsMenuItem.Name = "UnpackAssetsMenuItem"
        Me.UnpackAssetsMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.UnpackAssetsMenuItem.Text = "Unpack Assets"
        '
        'PreferencesToolStripMenu
        '
        Me.PreferencesToolStripMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoadPrefsMenuItem, Me.SavePrefsMenuItem})
        Me.PreferencesToolStripMenu.Name = "PreferencesToolStripMenu"
        Me.PreferencesToolStripMenu.Size = New System.Drawing.Size(80, 20)
        Me.PreferencesToolStripMenu.Text = "Preferences"
        '
        'LoadPrefsMenuItem
        '
        Me.LoadPrefsMenuItem.Name = "LoadPrefsMenuItem"
        Me.LoadPrefsMenuItem.Size = New System.Drawing.Size(100, 22)
        Me.LoadPrefsMenuItem.Text = "Load"
        '
        'SavePrefsMenuItem
        '
        Me.SavePrefsMenuItem.Name = "SavePrefsMenuItem"
        Me.SavePrefsMenuItem.Size = New System.Drawing.Size(100, 22)
        Me.SavePrefsMenuItem.Text = "Save"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem, Me.DocumentationMenuItem, Me.LicenseMenuItem, Me.READMEMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'DocumentationMenuItem
        '
        Me.DocumentationMenuItem.Name = "DocumentationMenuItem"
        Me.DocumentationMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.DocumentationMenuItem.Text = "Documentation"
        '
        'LicenseMenuItem
        '
        Me.LicenseMenuItem.Name = "LicenseMenuItem"
        Me.LicenseMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.LicenseMenuItem.Text = "License"
        '
        'READMEMenuItem
        '
        Me.READMEMenuItem.Name = "READMEMenuItem"
        Me.READMEMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.READMEMenuItem.Text = "README"
        '
        'ConvertPacksGroupBox
        '
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksSelectAllCheckBox)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksLogCheckBox)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksStartButton)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksSelectNoneButton)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksSelectAllButton)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksCheckedListBox)
        Me.ConvertPacksGroupBox.Controls.Add(Me.Label3)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksCleanUpCheckBox)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksDestinationTextBox)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksSourceTextBox)
        Me.ConvertPacksGroupBox.Controls.Add(Me.Label2)
        Me.ConvertPacksGroupBox.Controls.Add(Me.Label1)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksDestinationBrowseButton)
        Me.ConvertPacksGroupBox.Controls.Add(Me.ConvertPacksSourceBrowseButton)
        Me.ConvertPacksGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.ConvertPacksGroupBox.Name = "ConvertPacksGroupBox"
        Me.ConvertPacksGroupBox.Size = New System.Drawing.Size(758, 565)
        Me.ConvertPacksGroupBox.TabIndex = 1
        Me.ConvertPacksGroupBox.TabStop = False
        Me.ConvertPacksGroupBox.Text = "Convert Packs"
        Me.ConvertPacksGroupBox.Visible = False
        '
        'ConvertPacksSelectAllCheckBox
        '
        Me.ConvertPacksSelectAllCheckBox.AutoSize = True
        Me.ConvertPacksSelectAllCheckBox.Location = New System.Drawing.Point(538, 83)
        Me.ConvertPacksSelectAllCheckBox.Name = "ConvertPacksSelectAllCheckBox"
        Me.ConvertPacksSelectAllCheckBox.Size = New System.Drawing.Size(83, 20)
        Me.ConvertPacksSelectAllCheckBox.TabIndex = 6
        Me.ConvertPacksSelectAllCheckBox.Text = "Select All"
        Me.ConvertPacksSelectAllCheckBox.UseVisualStyleBackColor = True
        '
        'ConvertPacksLogCheckBox
        '
        Me.ConvertPacksLogCheckBox.AutoSize = True
        Me.ConvertPacksLogCheckBox.Location = New System.Drawing.Point(314, 83)
        Me.ConvertPacksLogCheckBox.Name = "ConvertPacksLogCheckBox"
        Me.ConvertPacksLogCheckBox.Size = New System.Drawing.Size(218, 20)
        Me.ConvertPacksLogCheckBox.TabIndex = 5
        Me.ConvertPacksLogCheckBox.Text = "Send ouput to ConvertPacks.log"
        Me.ConvertPacksLogCheckBox.UseVisualStyleBackColor = True
        '
        'ConvertPacksStartButton
        '
        Me.ConvertPacksStartButton.Location = New System.Drawing.Point(658, 194)
        Me.ConvertPacksStartButton.Name = "ConvertPacksStartButton"
        Me.ConvertPacksStartButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertPacksStartButton.TabIndex = 10
        Me.ConvertPacksStartButton.Text = "Start"
        Me.ConvertPacksStartButton.UseVisualStyleBackColor = True
        '
        'ConvertPacksSelectNoneButton
        '
        Me.ConvertPacksSelectNoneButton.Location = New System.Drawing.Point(658, 162)
        Me.ConvertPacksSelectNoneButton.Name = "ConvertPacksSelectNoneButton"
        Me.ConvertPacksSelectNoneButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertPacksSelectNoneButton.TabIndex = 9
        Me.ConvertPacksSelectNoneButton.Text = "Select None"
        Me.ConvertPacksSelectNoneButton.UseVisualStyleBackColor = True
        '
        'ConvertPacksSelectAllButton
        '
        Me.ConvertPacksSelectAllButton.Location = New System.Drawing.Point(658, 130)
        Me.ConvertPacksSelectAllButton.Name = "ConvertPacksSelectAllButton"
        Me.ConvertPacksSelectAllButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertPacksSelectAllButton.TabIndex = 8
        Me.ConvertPacksSelectAllButton.Text = "Select All"
        Me.ConvertPacksSelectAllButton.UseVisualStyleBackColor = True
        '
        'ConvertPacksCheckedListBox
        '
        Me.ConvertPacksCheckedListBox.CheckOnClick = True
        Me.ConvertPacksCheckedListBox.FormattingEnabled = True
        Me.ConvertPacksCheckedListBox.Location = New System.Drawing.Point(9, 130)
        Me.ConvertPacksCheckedListBox.Name = "ConvertPacksCheckedListBox"
        Me.ConvertPacksCheckedListBox.Size = New System.Drawing.Size(646, 429)
        Me.ConvertPacksCheckedListBox.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 111)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(134, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Pack Files to Convert"
        '
        'ConvertPacksCleanUpCheckBox
        '
        Me.ConvertPacksCleanUpCheckBox.AutoSize = True
        Me.ConvertPacksCleanUpCheckBox.Checked = True
        Me.ConvertPacksCleanUpCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ConvertPacksCleanUpCheckBox.Location = New System.Drawing.Point(39, 83)
        Me.ConvertPacksCleanUpCheckBox.Name = "ConvertPacksCleanUpCheckBox"
        Me.ConvertPacksCleanUpCheckBox.Size = New System.Drawing.Size(273, 20)
        Me.ConvertPacksCleanUpCheckBox.TabIndex = 4
        Me.ConvertPacksCleanUpCheckBox.Text = "Remove working folders after conversion."
        Me.ConvertPacksCleanUpCheckBox.UseVisualStyleBackColor = True
        '
        'ConvertPacksDestinationTextBox
        '
        Me.ConvertPacksDestinationTextBox.Location = New System.Drawing.Point(129, 55)
        Me.ConvertPacksDestinationTextBox.Name = "ConvertPacksDestinationTextBox"
        Me.ConvertPacksDestinationTextBox.Size = New System.Drawing.Size(523, 22)
        Me.ConvertPacksDestinationTextBox.TabIndex = 2
        '
        'ConvertPacksSourceTextBox
        '
        Me.ConvertPacksSourceTextBox.Location = New System.Drawing.Point(129, 23)
        Me.ConvertPacksSourceTextBox.Name = "ConvertPacksSourceTextBox"
        Me.ConvertPacksSourceTextBox.Size = New System.Drawing.Size(523, 22)
        Me.ConvertPacksSourceTextBox.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Destination Folder"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Source Folder"
        '
        'ConvertPacksDestinationBrowseButton
        '
        Me.ConvertPacksDestinationBrowseButton.Location = New System.Drawing.Point(658, 53)
        Me.ConvertPacksDestinationBrowseButton.Name = "ConvertPacksDestinationBrowseButton"
        Me.ConvertPacksDestinationBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertPacksDestinationBrowseButton.TabIndex = 3
        Me.ConvertPacksDestinationBrowseButton.Text = "Browse"
        Me.ConvertPacksDestinationBrowseButton.UseVisualStyleBackColor = True
        '
        'ConvertPacksSourceBrowseButton
        '
        Me.ConvertPacksSourceBrowseButton.Location = New System.Drawing.Point(658, 21)
        Me.ConvertPacksSourceBrowseButton.Name = "ConvertPacksSourceBrowseButton"
        Me.ConvertPacksSourceBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertPacksSourceBrowseButton.TabIndex = 1
        Me.ConvertPacksSourceBrowseButton.Text = "Browse"
        Me.ConvertPacksSourceBrowseButton.UseVisualStyleBackColor = True
        '
        'TagAssetsGroupBox
        '
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsSelectAllCheckBox)
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsLogCheckBox)
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsStartButton)
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsSelectNoneButton)
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsSelectAllButton)
        Me.TagAssetsGroupBox.Controls.Add(Me.Label6)
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsCheckedListBox)
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsDefaultTagTextBox)
        Me.TagAssetsGroupBox.Controls.Add(Me.Label5)
        Me.TagAssetsGroupBox.Controls.Add(Me.Label4)
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsSourceTextBox)
        Me.TagAssetsGroupBox.Controls.Add(Me.TagAssetsBrowseButton)
        Me.TagAssetsGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.TagAssetsGroupBox.Name = "TagAssetsGroupBox"
        Me.TagAssetsGroupBox.Size = New System.Drawing.Size(758, 565)
        Me.TagAssetsGroupBox.TabIndex = 2
        Me.TagAssetsGroupBox.TabStop = False
        Me.TagAssetsGroupBox.Text = "Tag Assets"
        Me.TagAssetsGroupBox.Visible = False
        '
        'TagAssetsSelectAllCheckBox
        '
        Me.TagAssetsSelectAllCheckBox.AutoSize = True
        Me.TagAssetsSelectAllCheckBox.Location = New System.Drawing.Point(314, 83)
        Me.TagAssetsSelectAllCheckBox.Name = "TagAssetsSelectAllCheckBox"
        Me.TagAssetsSelectAllCheckBox.Size = New System.Drawing.Size(83, 20)
        Me.TagAssetsSelectAllCheckBox.TabIndex = 4
        Me.TagAssetsSelectAllCheckBox.Text = "Select All"
        Me.TagAssetsSelectAllCheckBox.UseVisualStyleBackColor = True
        '
        'TagAssetsLogCheckBox
        '
        Me.TagAssetsLogCheckBox.AutoSize = True
        Me.TagAssetsLogCheckBox.Location = New System.Drawing.Point(105, 83)
        Me.TagAssetsLogCheckBox.Name = "TagAssetsLogCheckBox"
        Me.TagAssetsLogCheckBox.Size = New System.Drawing.Size(203, 20)
        Me.TagAssetsLogCheckBox.TabIndex = 3
        Me.TagAssetsLogCheckBox.Text = "Send output to TagAssets.log"
        Me.TagAssetsLogCheckBox.UseVisualStyleBackColor = True
        '
        'TagAssetsStartButton
        '
        Me.TagAssetsStartButton.Location = New System.Drawing.Point(658, 194)
        Me.TagAssetsStartButton.Name = "TagAssetsStartButton"
        Me.TagAssetsStartButton.Size = New System.Drawing.Size(94, 26)
        Me.TagAssetsStartButton.TabIndex = 8
        Me.TagAssetsStartButton.Text = "Start"
        Me.TagAssetsStartButton.UseVisualStyleBackColor = True
        '
        'TagAssetsSelectNoneButton
        '
        Me.TagAssetsSelectNoneButton.Location = New System.Drawing.Point(658, 162)
        Me.TagAssetsSelectNoneButton.Name = "TagAssetsSelectNoneButton"
        Me.TagAssetsSelectNoneButton.Size = New System.Drawing.Size(94, 26)
        Me.TagAssetsSelectNoneButton.TabIndex = 7
        Me.TagAssetsSelectNoneButton.Text = "Select None"
        Me.TagAssetsSelectNoneButton.UseVisualStyleBackColor = True
        '
        'TagAssetsSelectAllButton
        '
        Me.TagAssetsSelectAllButton.Location = New System.Drawing.Point(658, 130)
        Me.TagAssetsSelectAllButton.Name = "TagAssetsSelectAllButton"
        Me.TagAssetsSelectAllButton.Size = New System.Drawing.Size(94, 26)
        Me.TagAssetsSelectAllButton.TabIndex = 6
        Me.TagAssetsSelectAllButton.Text = "Select All"
        Me.TagAssetsSelectAllButton.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 111)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(96, 16)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Folders to Tag"
        '
        'TagAssetsCheckedListBox
        '
        Me.TagAssetsCheckedListBox.CheckOnClick = True
        Me.TagAssetsCheckedListBox.FormattingEnabled = True
        Me.TagAssetsCheckedListBox.Location = New System.Drawing.Point(6, 130)
        Me.TagAssetsCheckedListBox.Name = "TagAssetsCheckedListBox"
        Me.TagAssetsCheckedListBox.Size = New System.Drawing.Size(646, 429)
        Me.TagAssetsCheckedListBox.TabIndex = 5
        '
        'TagAssetsDefaultTagTextBox
        '
        Me.TagAssetsDefaultTagTextBox.Location = New System.Drawing.Point(105, 55)
        Me.TagAssetsDefaultTagTextBox.Name = "TagAssetsDefaultTagTextBox"
        Me.TagAssetsDefaultTagTextBox.Size = New System.Drawing.Size(547, 22)
        Me.TagAssetsDefaultTagTextBox.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(21, 58)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 16)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Default Tag"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 16)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Source Folder"
        '
        'TagAssetsSourceTextBox
        '
        Me.TagAssetsSourceTextBox.Location = New System.Drawing.Point(105, 23)
        Me.TagAssetsSourceTextBox.Name = "TagAssetsSourceTextBox"
        Me.TagAssetsSourceTextBox.Size = New System.Drawing.Size(547, 22)
        Me.TagAssetsSourceTextBox.TabIndex = 0
        '
        'TagAssetsBrowseButton
        '
        Me.TagAssetsBrowseButton.Location = New System.Drawing.Point(658, 21)
        Me.TagAssetsBrowseButton.Name = "TagAssetsBrowseButton"
        Me.TagAssetsBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.TagAssetsBrowseButton.TabIndex = 1
        Me.TagAssetsBrowseButton.Text = "Browse"
        Me.TagAssetsBrowseButton.UseVisualStyleBackColor = True
        '
        'CopyAssetsGroupBox
        '
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsSelectAllCheckBox)
        Me.CopyAssetsGroupBox.Controls.Add(Me.Label21)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsSelectNoneButton)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsSelectAllButton)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsCheckedListBox)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsLogCheckBox)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsPortalsCheckBox)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsCreateTagsCheckBox)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsSourceTextBox)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsDestinationTextBox)
        Me.CopyAssetsGroupBox.Controls.Add(Me.Label8)
        Me.CopyAssetsGroupBox.Controls.Add(Me.Label7)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsStartButton)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsDestinationBrowseButton)
        Me.CopyAssetsGroupBox.Controls.Add(Me.CopyAssetsSourceBrowseButton)
        Me.CopyAssetsGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.CopyAssetsGroupBox.Name = "CopyAssetsGroupBox"
        Me.CopyAssetsGroupBox.Size = New System.Drawing.Size(758, 565)
        Me.CopyAssetsGroupBox.TabIndex = 3
        Me.CopyAssetsGroupBox.TabStop = False
        Me.CopyAssetsGroupBox.Text = "Copy Assets"
        Me.CopyAssetsGroupBox.Visible = False
        '
        'CopyAssetsSelectAllCheckBox
        '
        Me.CopyAssetsSelectAllCheckBox.AutoSize = True
        Me.CopyAssetsSelectAllCheckBox.Location = New System.Drawing.Point(522, 83)
        Me.CopyAssetsSelectAllCheckBox.Name = "CopyAssetsSelectAllCheckBox"
        Me.CopyAssetsSelectAllCheckBox.Size = New System.Drawing.Size(83, 20)
        Me.CopyAssetsSelectAllCheckBox.TabIndex = 7
        Me.CopyAssetsSelectAllCheckBox.Text = "Select All"
        Me.CopyAssetsSelectAllCheckBox.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(6, 111)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(140, 16)
        Me.Label21.TabIndex = 11
        Me.Label21.Text = "Asset Folders to Copy"
        '
        'CopyAssetsSelectNoneButton
        '
        Me.CopyAssetsSelectNoneButton.Location = New System.Drawing.Point(658, 162)
        Me.CopyAssetsSelectNoneButton.Name = "CopyAssetsSelectNoneButton"
        Me.CopyAssetsSelectNoneButton.Size = New System.Drawing.Size(94, 26)
        Me.CopyAssetsSelectNoneButton.TabIndex = 10
        Me.CopyAssetsSelectNoneButton.Text = "Select None"
        Me.CopyAssetsSelectNoneButton.UseVisualStyleBackColor = True
        '
        'CopyAssetsSelectAllButton
        '
        Me.CopyAssetsSelectAllButton.Location = New System.Drawing.Point(658, 130)
        Me.CopyAssetsSelectAllButton.Name = "CopyAssetsSelectAllButton"
        Me.CopyAssetsSelectAllButton.Size = New System.Drawing.Size(94, 26)
        Me.CopyAssetsSelectAllButton.TabIndex = 9
        Me.CopyAssetsSelectAllButton.Text = "Select All"
        Me.CopyAssetsSelectAllButton.UseVisualStyleBackColor = True
        '
        'CopyAssetsCheckedListBox
        '
        Me.CopyAssetsCheckedListBox.CheckOnClick = True
        Me.CopyAssetsCheckedListBox.FormattingEnabled = True
        Me.CopyAssetsCheckedListBox.Location = New System.Drawing.Point(9, 130)
        Me.CopyAssetsCheckedListBox.Name = "CopyAssetsCheckedListBox"
        Me.CopyAssetsCheckedListBox.Size = New System.Drawing.Size(646, 429)
        Me.CopyAssetsCheckedListBox.TabIndex = 8
        '
        'CopyAssetsLogCheckBox
        '
        Me.CopyAssetsLogCheckBox.AutoSize = True
        Me.CopyAssetsLogCheckBox.Location = New System.Drawing.Point(306, 83)
        Me.CopyAssetsLogCheckBox.Name = "CopyAssetsLogCheckBox"
        Me.CopyAssetsLogCheckBox.Size = New System.Drawing.Size(210, 20)
        Me.CopyAssetsLogCheckBox.TabIndex = 6
        Me.CopyAssetsLogCheckBox.Text = "Send output to CopyAssets.log"
        Me.CopyAssetsLogCheckBox.UseVisualStyleBackColor = True
        '
        'CopyAssetsPortalsCheckBox
        '
        Me.CopyAssetsPortalsCheckBox.AutoSize = True
        Me.CopyAssetsPortalsCheckBox.Checked = True
        Me.CopyAssetsPortalsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CopyAssetsPortalsCheckBox.Location = New System.Drawing.Point(172, 83)
        Me.CopyAssetsPortalsCheckBox.Name = "CopyAssetsPortalsCheckBox"
        Me.CopyAssetsPortalsCheckBox.Size = New System.Drawing.Size(128, 20)
        Me.CopyAssetsPortalsCheckBox.TabIndex = 5
        Me.CopyAssetsPortalsCheckBox.Text = "Separate Portals"
        Me.CopyAssetsPortalsCheckBox.UseVisualStyleBackColor = True
        '
        'CopyAssetsCreateTagsCheckBox
        '
        Me.CopyAssetsCreateTagsCheckBox.AutoSize = True
        Me.CopyAssetsCreateTagsCheckBox.Location = New System.Drawing.Point(39, 83)
        Me.CopyAssetsCreateTagsCheckBox.Name = "CopyAssetsCreateTagsCheckBox"
        Me.CopyAssetsCreateTagsCheckBox.Size = New System.Drawing.Size(127, 20)
        Me.CopyAssetsCreateTagsCheckBox.TabIndex = 4
        Me.CopyAssetsCreateTagsCheckBox.Text = "Create Tags File"
        Me.CopyAssetsCreateTagsCheckBox.UseVisualStyleBackColor = True
        '
        'CopyAssetsSourceTextBox
        '
        Me.CopyAssetsSourceTextBox.Location = New System.Drawing.Point(129, 23)
        Me.CopyAssetsSourceTextBox.Name = "CopyAssetsSourceTextBox"
        Me.CopyAssetsSourceTextBox.Size = New System.Drawing.Size(523, 22)
        Me.CopyAssetsSourceTextBox.TabIndex = 0
        '
        'CopyAssetsDestinationTextBox
        '
        Me.CopyAssetsDestinationTextBox.Location = New System.Drawing.Point(129, 55)
        Me.CopyAssetsDestinationTextBox.Name = "CopyAssetsDestinationTextBox"
        Me.CopyAssetsDestinationTextBox.Size = New System.Drawing.Size(523, 22)
        Me.CopyAssetsDestinationTextBox.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 58)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 16)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Destination Folder"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(30, 26)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 16)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Source Folder"
        '
        'CopyAssetsStartButton
        '
        Me.CopyAssetsStartButton.Location = New System.Drawing.Point(658, 194)
        Me.CopyAssetsStartButton.Name = "CopyAssetsStartButton"
        Me.CopyAssetsStartButton.Size = New System.Drawing.Size(94, 26)
        Me.CopyAssetsStartButton.TabIndex = 11
        Me.CopyAssetsStartButton.Text = "Start"
        Me.CopyAssetsStartButton.UseVisualStyleBackColor = True
        '
        'CopyAssetsDestinationBrowseButton
        '
        Me.CopyAssetsDestinationBrowseButton.Location = New System.Drawing.Point(658, 53)
        Me.CopyAssetsDestinationBrowseButton.Name = "CopyAssetsDestinationBrowseButton"
        Me.CopyAssetsDestinationBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.CopyAssetsDestinationBrowseButton.TabIndex = 3
        Me.CopyAssetsDestinationBrowseButton.Text = "Browse"
        Me.CopyAssetsDestinationBrowseButton.UseVisualStyleBackColor = True
        '
        'CopyAssetsSourceBrowseButton
        '
        Me.CopyAssetsSourceBrowseButton.Location = New System.Drawing.Point(658, 21)
        Me.CopyAssetsSourceBrowseButton.Name = "CopyAssetsSourceBrowseButton"
        Me.CopyAssetsSourceBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.CopyAssetsSourceBrowseButton.TabIndex = 1
        Me.CopyAssetsSourceBrowseButton.Text = "Browse"
        Me.CopyAssetsSourceBrowseButton.UseVisualStyleBackColor = True
        '
        'ConvertAssetsGroupBox
        '
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsSelectAllCheckBox)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.Label20)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsSelectNoneButton)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsSelectAllButton)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsCheckedListBox)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsLogCheckBox)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.Label10)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsSourceTextBox)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsDestinationTextBox)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.Label9)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsStartButton)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsDestinationBrowseButton)
        Me.ConvertAssetsGroupBox.Controls.Add(Me.ConvertAssetsSourceBrowseButton)
        Me.ConvertAssetsGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.ConvertAssetsGroupBox.Name = "ConvertAssetsGroupBox"
        Me.ConvertAssetsGroupBox.Size = New System.Drawing.Size(758, 565)
        Me.ConvertAssetsGroupBox.TabIndex = 7
        Me.ConvertAssetsGroupBox.TabStop = False
        Me.ConvertAssetsGroupBox.Text = "Convert Assets"
        Me.ConvertAssetsGroupBox.Visible = False
        '
        'ConvertAssetsSelectAllCheckBox
        '
        Me.ConvertAssetsSelectAllCheckBox.AutoSize = True
        Me.ConvertAssetsSelectAllCheckBox.Location = New System.Drawing.Point(359, 83)
        Me.ConvertAssetsSelectAllCheckBox.Name = "ConvertAssetsSelectAllCheckBox"
        Me.ConvertAssetsSelectAllCheckBox.Size = New System.Drawing.Size(83, 20)
        Me.ConvertAssetsSelectAllCheckBox.TabIndex = 5
        Me.ConvertAssetsSelectAllCheckBox.Text = "Select All"
        Me.ConvertAssetsSelectAllCheckBox.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(6, 111)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(154, 16)
        Me.Label20.TabIndex = 9
        Me.Label20.Text = "Asset Folders to Convert"
        '
        'ConvertAssetsSelectNoneButton
        '
        Me.ConvertAssetsSelectNoneButton.Location = New System.Drawing.Point(658, 162)
        Me.ConvertAssetsSelectNoneButton.Name = "ConvertAssetsSelectNoneButton"
        Me.ConvertAssetsSelectNoneButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertAssetsSelectNoneButton.TabIndex = 8
        Me.ConvertAssetsSelectNoneButton.Text = "Select None"
        Me.ConvertAssetsSelectNoneButton.UseVisualStyleBackColor = True
        '
        'ConvertAssetsSelectAllButton
        '
        Me.ConvertAssetsSelectAllButton.Location = New System.Drawing.Point(658, 130)
        Me.ConvertAssetsSelectAllButton.Name = "ConvertAssetsSelectAllButton"
        Me.ConvertAssetsSelectAllButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertAssetsSelectAllButton.TabIndex = 7
        Me.ConvertAssetsSelectAllButton.Text = "Select All"
        Me.ConvertAssetsSelectAllButton.UseVisualStyleBackColor = True
        '
        'ConvertAssetsCheckedListBox
        '
        Me.ConvertAssetsCheckedListBox.CheckOnClick = True
        Me.ConvertAssetsCheckedListBox.FormattingEnabled = True
        Me.ConvertAssetsCheckedListBox.Location = New System.Drawing.Point(9, 130)
        Me.ConvertAssetsCheckedListBox.Name = "ConvertAssetsCheckedListBox"
        Me.ConvertAssetsCheckedListBox.Size = New System.Drawing.Size(646, 429)
        Me.ConvertAssetsCheckedListBox.TabIndex = 6
        '
        'ConvertAssetsLogCheckBox
        '
        Me.ConvertAssetsLogCheckBox.AutoSize = True
        Me.ConvertAssetsLogCheckBox.Location = New System.Drawing.Point(129, 83)
        Me.ConvertAssetsLogCheckBox.Name = "ConvertAssetsLogCheckBox"
        Me.ConvertAssetsLogCheckBox.Size = New System.Drawing.Size(224, 20)
        Me.ConvertAssetsLogCheckBox.TabIndex = 4
        Me.ConvertAssetsLogCheckBox.Text = "Send output to ConvertAssets.log"
        Me.ConvertAssetsLogCheckBox.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(30, 26)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(93, 16)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Source Folder"
        '
        'ConvertAssetsSourceTextBox
        '
        Me.ConvertAssetsSourceTextBox.Location = New System.Drawing.Point(129, 23)
        Me.ConvertAssetsSourceTextBox.Name = "ConvertAssetsSourceTextBox"
        Me.ConvertAssetsSourceTextBox.Size = New System.Drawing.Size(523, 22)
        Me.ConvertAssetsSourceTextBox.TabIndex = 0
        '
        'ConvertAssetsDestinationTextBox
        '
        Me.ConvertAssetsDestinationTextBox.Location = New System.Drawing.Point(129, 55)
        Me.ConvertAssetsDestinationTextBox.Name = "ConvertAssetsDestinationTextBox"
        Me.ConvertAssetsDestinationTextBox.Size = New System.Drawing.Size(523, 22)
        Me.ConvertAssetsDestinationTextBox.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 58)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(117, 16)
        Me.Label9.TabIndex = 3
        Me.Label9.Text = "Destination Folder"
        '
        'ConvertAssetsStartButton
        '
        Me.ConvertAssetsStartButton.Location = New System.Drawing.Point(658, 194)
        Me.ConvertAssetsStartButton.Name = "ConvertAssetsStartButton"
        Me.ConvertAssetsStartButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertAssetsStartButton.TabIndex = 9
        Me.ConvertAssetsStartButton.Text = "Start"
        Me.ConvertAssetsStartButton.UseVisualStyleBackColor = True
        '
        'ConvertAssetsDestinationBrowseButton
        '
        Me.ConvertAssetsDestinationBrowseButton.Location = New System.Drawing.Point(658, 53)
        Me.ConvertAssetsDestinationBrowseButton.Name = "ConvertAssetsDestinationBrowseButton"
        Me.ConvertAssetsDestinationBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertAssetsDestinationBrowseButton.TabIndex = 3
        Me.ConvertAssetsDestinationBrowseButton.Text = "Browse"
        Me.ConvertAssetsDestinationBrowseButton.UseVisualStyleBackColor = True
        '
        'ConvertAssetsSourceBrowseButton
        '
        Me.ConvertAssetsSourceBrowseButton.Location = New System.Drawing.Point(658, 21)
        Me.ConvertAssetsSourceBrowseButton.Name = "ConvertAssetsSourceBrowseButton"
        Me.ConvertAssetsSourceBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.ConvertAssetsSourceBrowseButton.TabIndex = 1
        Me.ConvertAssetsSourceBrowseButton.Text = "Browse"
        Me.ConvertAssetsSourceBrowseButton.UseVisualStyleBackColor = True
        '
        'TitlePanel
        '
        Me.TitlePanel.Controls.Add(Me.PictureBox2)
        Me.TitlePanel.Controls.Add(Me.VersionLabel)
        Me.TitlePanel.Controls.Add(Me.CreativeCommonsLinkLabel)
        Me.TitlePanel.Controls.Add(Me.GitHubLinkLabel)
        Me.TitlePanel.Controls.Add(Me.EmailLinkLabel)
        Me.TitlePanel.Controls.Add(Me.PictureBox1)
        Me.TitlePanel.Controls.Add(Me.Label13)
        Me.TitlePanel.Controls.Add(Me.Label12)
        Me.TitlePanel.Location = New System.Drawing.Point(12, 33)
        Me.TitlePanel.Name = "TitlePanel"
        Me.TitlePanel.Size = New System.Drawing.Size(956, 365)
        Me.TitlePanel.TabIndex = 8
        Me.TitlePanel.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(0, 298)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(956, 43)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 8
        Me.PictureBox2.TabStop = False
        '
        'VersionLabel
        '
        Me.VersionLabel.AutoSize = True
        Me.VersionLabel.Font = New System.Drawing.Font("Cagliostro", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.VersionLabel.Location = New System.Drawing.Point(246, 83)
        Me.VersionLabel.Name = "VersionLabel"
        Me.VersionLabel.Size = New System.Drawing.Size(122, 43)
        Me.VersionLabel.TabIndex = 7
        Me.VersionLabel.Text = "Version"
        '
        'CreativeCommonsLinkLabel
        '
        Me.CreativeCommonsLinkLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CreativeCommonsLinkLabel.Location = New System.Drawing.Point(0, 256)
        Me.CreativeCommonsLinkLabel.Name = "CreativeCommonsLinkLabel"
        Me.CreativeCommonsLinkLabel.Size = New System.Drawing.Size(956, 30)
        Me.CreativeCommonsLinkLabel.TabIndex = 6
        Me.CreativeCommonsLinkLabel.TabStop = True
        Me.CreativeCommonsLinkLabel.Text = "LinkLabel3"
        Me.CreativeCommonsLinkLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GitHubLinkLabel
        '
        Me.GitHubLinkLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GitHubLinkLabel.Location = New System.Drawing.Point(0, 226)
        Me.GitHubLinkLabel.Name = "GitHubLinkLabel"
        Me.GitHubLinkLabel.Size = New System.Drawing.Size(956, 30)
        Me.GitHubLinkLabel.TabIndex = 5
        Me.GitHubLinkLabel.TabStop = True
        Me.GitHubLinkLabel.Text = "GitHubLinkLabel"
        Me.GitHubLinkLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'EmailLinkLabel
        '
        Me.EmailLinkLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmailLinkLabel.Location = New System.Drawing.Point(0, 193)
        Me.EmailLinkLabel.Name = "EmailLinkLabel"
        Me.EmailLinkLabel.Size = New System.Drawing.Size(956, 30)
        Me.EmailLinkLabel.TabIndex = 4
        Me.EmailLinkLabel.TabStop = True
        Me.EmailLinkLabel.Text = "LinkLabel1"
        Me.EmailLinkLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(6, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(231, 124)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Cagliostro", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(0, 145)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(956, 43)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Copyright © 2020 EightBitz, Creative Commons CC-BY-NC"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Cagliostro", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(243, 3)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(678, 65)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "EightBitz's Dungeondraft Tools"
        '
        'UnpackAssetsGroupBox
        '
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsSelectAllCheckBox)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsLogCheckBox)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsStartButton)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsSelectNoneButton)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsSelectAllButton)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.Label16)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsCheckedListBox)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.Label15)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsSourceTextBox)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsDestinationTextBox)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.Label14)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsDestinationBrowseButton)
        Me.UnpackAssetsGroupBox.Controls.Add(Me.UnpackAssetsSourceBrowseButton)
        Me.UnpackAssetsGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.UnpackAssetsGroupBox.Name = "UnpackAssetsGroupBox"
        Me.UnpackAssetsGroupBox.Size = New System.Drawing.Size(758, 565)
        Me.UnpackAssetsGroupBox.TabIndex = 10
        Me.UnpackAssetsGroupBox.TabStop = False
        Me.UnpackAssetsGroupBox.Text = "Unpack Assets"
        Me.UnpackAssetsGroupBox.Visible = False
        '
        'UnpackAssetsSelectAllCheckBox
        '
        Me.UnpackAssetsSelectAllCheckBox.AutoSize = True
        Me.UnpackAssetsSelectAllCheckBox.Location = New System.Drawing.Point(360, 83)
        Me.UnpackAssetsSelectAllCheckBox.Name = "UnpackAssetsSelectAllCheckBox"
        Me.UnpackAssetsSelectAllCheckBox.Size = New System.Drawing.Size(83, 20)
        Me.UnpackAssetsSelectAllCheckBox.TabIndex = 5
        Me.UnpackAssetsSelectAllCheckBox.Text = "Select All"
        Me.UnpackAssetsSelectAllCheckBox.UseVisualStyleBackColor = True
        '
        'UnpackAssetsLogCheckBox
        '
        Me.UnpackAssetsLogCheckBox.AutoSize = True
        Me.UnpackAssetsLogCheckBox.Location = New System.Drawing.Point(129, 83)
        Me.UnpackAssetsLogCheckBox.Name = "UnpackAssetsLogCheckBox"
        Me.UnpackAssetsLogCheckBox.Size = New System.Drawing.Size(225, 20)
        Me.UnpackAssetsLogCheckBox.TabIndex = 4
        Me.UnpackAssetsLogCheckBox.Text = "Send output to UnpackAssets.log"
        Me.UnpackAssetsLogCheckBox.UseVisualStyleBackColor = True
        '
        'UnpackAssetsStartButton
        '
        Me.UnpackAssetsStartButton.Location = New System.Drawing.Point(658, 194)
        Me.UnpackAssetsStartButton.Name = "UnpackAssetsStartButton"
        Me.UnpackAssetsStartButton.Size = New System.Drawing.Size(94, 26)
        Me.UnpackAssetsStartButton.TabIndex = 9
        Me.UnpackAssetsStartButton.Text = "Start"
        Me.UnpackAssetsStartButton.UseVisualStyleBackColor = True
        '
        'UnpackAssetsSelectNoneButton
        '
        Me.UnpackAssetsSelectNoneButton.Location = New System.Drawing.Point(658, 162)
        Me.UnpackAssetsSelectNoneButton.Name = "UnpackAssetsSelectNoneButton"
        Me.UnpackAssetsSelectNoneButton.Size = New System.Drawing.Size(94, 26)
        Me.UnpackAssetsSelectNoneButton.TabIndex = 8
        Me.UnpackAssetsSelectNoneButton.Text = "Select None"
        Me.UnpackAssetsSelectNoneButton.UseVisualStyleBackColor = True
        '
        'UnpackAssetsSelectAllButton
        '
        Me.UnpackAssetsSelectAllButton.Location = New System.Drawing.Point(658, 130)
        Me.UnpackAssetsSelectAllButton.Name = "UnpackAssetsSelectAllButton"
        Me.UnpackAssetsSelectAllButton.Size = New System.Drawing.Size(94, 26)
        Me.UnpackAssetsSelectAllButton.TabIndex = 7
        Me.UnpackAssetsSelectAllButton.Text = "Select All"
        Me.UnpackAssetsSelectAllButton.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 111)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(135, 16)
        Me.Label16.TabIndex = 7
        Me.Label16.Text = "Pack Files to Unpack"
        '
        'UnpackAssetsCheckedListBox
        '
        Me.UnpackAssetsCheckedListBox.CheckOnClick = True
        Me.UnpackAssetsCheckedListBox.FormattingEnabled = True
        Me.UnpackAssetsCheckedListBox.Location = New System.Drawing.Point(9, 130)
        Me.UnpackAssetsCheckedListBox.Name = "UnpackAssetsCheckedListBox"
        Me.UnpackAssetsCheckedListBox.Size = New System.Drawing.Size(646, 429)
        Me.UnpackAssetsCheckedListBox.TabIndex = 6
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(30, 26)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(93, 16)
        Me.Label15.TabIndex = 5
        Me.Label15.Text = "Source Folder"
        '
        'UnpackAssetsSourceTextBox
        '
        Me.UnpackAssetsSourceTextBox.Location = New System.Drawing.Point(129, 23)
        Me.UnpackAssetsSourceTextBox.Name = "UnpackAssetsSourceTextBox"
        Me.UnpackAssetsSourceTextBox.Size = New System.Drawing.Size(523, 22)
        Me.UnpackAssetsSourceTextBox.TabIndex = 0
        '
        'UnpackAssetsDestinationTextBox
        '
        Me.UnpackAssetsDestinationTextBox.Location = New System.Drawing.Point(129, 55)
        Me.UnpackAssetsDestinationTextBox.Name = "UnpackAssetsDestinationTextBox"
        Me.UnpackAssetsDestinationTextBox.Size = New System.Drawing.Size(523, 22)
        Me.UnpackAssetsDestinationTextBox.TabIndex = 2
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 58)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(117, 16)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Destination Folder"
        '
        'UnpackAssetsDestinationBrowseButton
        '
        Me.UnpackAssetsDestinationBrowseButton.Location = New System.Drawing.Point(658, 53)
        Me.UnpackAssetsDestinationBrowseButton.Name = "UnpackAssetsDestinationBrowseButton"
        Me.UnpackAssetsDestinationBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.UnpackAssetsDestinationBrowseButton.TabIndex = 3
        Me.UnpackAssetsDestinationBrowseButton.Text = "Browse"
        Me.UnpackAssetsDestinationBrowseButton.UseVisualStyleBackColor = True
        '
        'UnpackAssetsSourceBrowseButton
        '
        Me.UnpackAssetsSourceBrowseButton.Location = New System.Drawing.Point(658, 21)
        Me.UnpackAssetsSourceBrowseButton.Name = "UnpackAssetsSourceBrowseButton"
        Me.UnpackAssetsSourceBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.UnpackAssetsSourceBrowseButton.TabIndex = 1
        Me.UnpackAssetsSourceBrowseButton.Text = "Browse"
        Me.UnpackAssetsSourceBrowseButton.UseVisualStyleBackColor = True
        '
        'PackAssetsGroupBox
        '
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsSelectAllCheckBox)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsOverwriteCheckBox)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsRefreshButton)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsLogCheckBox)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsDataGridView)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsStartButton)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsSelectNoneButton)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsSelectAllButton)
        Me.PackAssetsGroupBox.Controls.Add(Me.Label17)
        Me.PackAssetsGroupBox.Controls.Add(Me.Label18)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsSourceTextBox)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsDestinationTextBox)
        Me.PackAssetsGroupBox.Controls.Add(Me.Label19)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsDestinationBrowseButton)
        Me.PackAssetsGroupBox.Controls.Add(Me.PackAssetsSourceBrowseButton)
        Me.PackAssetsGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.PackAssetsGroupBox.Name = "PackAssetsGroupBox"
        Me.PackAssetsGroupBox.Size = New System.Drawing.Size(956, 565)
        Me.PackAssetsGroupBox.TabIndex = 11
        Me.PackAssetsGroupBox.TabStop = False
        Me.PackAssetsGroupBox.Text = "Pack Assets"
        Me.PackAssetsGroupBox.Visible = False
        '
        'PackAssetsSelectAllCheckBox
        '
        Me.PackAssetsSelectAllCheckBox.AutoSize = True
        Me.PackAssetsSelectAllCheckBox.Location = New System.Drawing.Point(555, 83)
        Me.PackAssetsSelectAllCheckBox.Name = "PackAssetsSelectAllCheckBox"
        Me.PackAssetsSelectAllCheckBox.Size = New System.Drawing.Size(83, 20)
        Me.PackAssetsSelectAllCheckBox.TabIndex = 6
        Me.PackAssetsSelectAllCheckBox.Text = "Select All"
        Me.PackAssetsSelectAllCheckBox.UseVisualStyleBackColor = True
        '
        'PackAssetsOverwriteCheckBox
        '
        Me.PackAssetsOverwriteCheckBox.AutoSize = True
        Me.PackAssetsOverwriteCheckBox.Location = New System.Drawing.Point(129, 83)
        Me.PackAssetsOverwriteCheckBox.Name = "PackAssetsOverwriteCheckBox"
        Me.PackAssetsOverwriteCheckBox.Size = New System.Drawing.Size(194, 20)
        Me.PackAssetsOverwriteCheckBox.TabIndex = 4
        Me.PackAssetsOverwriteCheckBox.Text = "Overwrite files in destination."
        Me.PackAssetsOverwriteCheckBox.UseVisualStyleBackColor = True
        '
        'PackAssetsRefreshButton
        '
        Me.PackAssetsRefreshButton.Location = New System.Drawing.Point(856, 130)
        Me.PackAssetsRefreshButton.Name = "PackAssetsRefreshButton"
        Me.PackAssetsRefreshButton.Size = New System.Drawing.Size(94, 26)
        Me.PackAssetsRefreshButton.TabIndex = 8
        Me.PackAssetsRefreshButton.Text = "Refresh"
        Me.PackAssetsRefreshButton.UseVisualStyleBackColor = True
        '
        'PackAssetsLogCheckBox
        '
        Me.PackAssetsLogCheckBox.AutoSize = True
        Me.PackAssetsLogCheckBox.Location = New System.Drawing.Point(329, 83)
        Me.PackAssetsLogCheckBox.Name = "PackAssetsLogCheckBox"
        Me.PackAssetsLogCheckBox.Size = New System.Drawing.Size(209, 20)
        Me.PackAssetsLogCheckBox.TabIndex = 5
        Me.PackAssetsLogCheckBox.Text = "Send output to PackAssets.log"
        Me.PackAssetsLogCheckBox.UseVisualStyleBackColor = True
        '
        'PackAssetsDataGridView
        '
        Me.PackAssetsDataGridView.AllowUserToAddRows = False
        Me.PackAssetsDataGridView.AllowUserToDeleteRows = False
        Me.PackAssetsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PackAssetsDataGridView.Location = New System.Drawing.Point(9, 130)
        Me.PackAssetsDataGridView.Name = "PackAssetsDataGridView"
        Me.PackAssetsDataGridView.Size = New System.Drawing.Size(841, 429)
        Me.PackAssetsDataGridView.TabIndex = 7
        '
        'PackAssetsStartButton
        '
        Me.PackAssetsStartButton.Location = New System.Drawing.Point(856, 226)
        Me.PackAssetsStartButton.Name = "PackAssetsStartButton"
        Me.PackAssetsStartButton.Size = New System.Drawing.Size(94, 26)
        Me.PackAssetsStartButton.TabIndex = 11
        Me.PackAssetsStartButton.Text = "Start"
        Me.PackAssetsStartButton.UseVisualStyleBackColor = True
        '
        'PackAssetsSelectNoneButton
        '
        Me.PackAssetsSelectNoneButton.Location = New System.Drawing.Point(856, 194)
        Me.PackAssetsSelectNoneButton.Name = "PackAssetsSelectNoneButton"
        Me.PackAssetsSelectNoneButton.Size = New System.Drawing.Size(94, 26)
        Me.PackAssetsSelectNoneButton.TabIndex = 10
        Me.PackAssetsSelectNoneButton.Text = "Select None"
        Me.PackAssetsSelectNoneButton.UseVisualStyleBackColor = True
        '
        'PackAssetsSelectAllButton
        '
        Me.PackAssetsSelectAllButton.Location = New System.Drawing.Point(856, 162)
        Me.PackAssetsSelectAllButton.Name = "PackAssetsSelectAllButton"
        Me.PackAssetsSelectAllButton.Size = New System.Drawing.Size(94, 26)
        Me.PackAssetsSelectAllButton.TabIndex = 9
        Me.PackAssetsSelectAllButton.Text = "Select All"
        Me.PackAssetsSelectAllButton.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(6, 111)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(139, 16)
        Me.Label17.TabIndex = 7
        Me.Label17.Text = "Asset Folders to Pack"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(30, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(93, 16)
        Me.Label18.TabIndex = 5
        Me.Label18.Text = "Source Folder"
        '
        'PackAssetsSourceTextBox
        '
        Me.PackAssetsSourceTextBox.Location = New System.Drawing.Point(129, 23)
        Me.PackAssetsSourceTextBox.Name = "PackAssetsSourceTextBox"
        Me.PackAssetsSourceTextBox.Size = New System.Drawing.Size(721, 22)
        Me.PackAssetsSourceTextBox.TabIndex = 0
        '
        'PackAssetsDestinationTextBox
        '
        Me.PackAssetsDestinationTextBox.Location = New System.Drawing.Point(129, 55)
        Me.PackAssetsDestinationTextBox.Name = "PackAssetsDestinationTextBox"
        Me.PackAssetsDestinationTextBox.Size = New System.Drawing.Size(721, 22)
        Me.PackAssetsDestinationTextBox.TabIndex = 2
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(6, 58)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(117, 16)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Destination Folder"
        '
        'PackAssetsDestinationBrowseButton
        '
        Me.PackAssetsDestinationBrowseButton.Location = New System.Drawing.Point(856, 53)
        Me.PackAssetsDestinationBrowseButton.Name = "PackAssetsDestinationBrowseButton"
        Me.PackAssetsDestinationBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.PackAssetsDestinationBrowseButton.TabIndex = 3
        Me.PackAssetsDestinationBrowseButton.Text = "Browse"
        Me.PackAssetsDestinationBrowseButton.UseVisualStyleBackColor = True
        '
        'PackAssetsSourceBrowseButton
        '
        Me.PackAssetsSourceBrowseButton.Location = New System.Drawing.Point(856, 21)
        Me.PackAssetsSourceBrowseButton.Name = "PackAssetsSourceBrowseButton"
        Me.PackAssetsSourceBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.PackAssetsSourceBrowseButton.TabIndex = 1
        Me.PackAssetsSourceBrowseButton.Text = "Browse"
        Me.PackAssetsSourceBrowseButton.UseVisualStyleBackColor = True
        '
        'CopyTilesGroupBox
        '
        Me.CopyTilesGroupBox.Controls.Add(Me.CopyTilesSelectAllCheckBox)
        Me.CopyTilesGroupBox.Controls.Add(Me.CopyTilesDataGridView)
        Me.CopyTilesGroupBox.Controls.Add(Me.Label22)
        Me.CopyTilesGroupBox.Controls.Add(Me.CopyTilesLogCheckBox)
        Me.CopyTilesGroupBox.Controls.Add(Me.CopyTilesSourceTextBox)
        Me.CopyTilesGroupBox.Controls.Add(Me.CopyTilesDestinationTextBox)
        Me.CopyTilesGroupBox.Controls.Add(Me.Label23)
        Me.CopyTilesGroupBox.Controls.Add(Me.Label24)
        Me.CopyTilesGroupBox.Controls.Add(Me.CopyTilesStartButton)
        Me.CopyTilesGroupBox.Controls.Add(Me.CopyTilesDestinationBrowseButton)
        Me.CopyTilesGroupBox.Controls.Add(Me.CopyTilesSourceBrowseButton)
        Me.CopyTilesGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.CopyTilesGroupBox.Name = "CopyTilesGroupBox"
        Me.CopyTilesGroupBox.Size = New System.Drawing.Size(758, 565)
        Me.CopyTilesGroupBox.TabIndex = 12
        Me.CopyTilesGroupBox.TabStop = False
        Me.CopyTilesGroupBox.Text = "Copy Tiles"
        Me.CopyTilesGroupBox.Visible = False
        '
        'CopyTilesSelectAllCheckBox
        '
        Me.CopyTilesSelectAllCheckBox.AutoSize = True
        Me.CopyTilesSelectAllCheckBox.Location = New System.Drawing.Point(334, 83)
        Me.CopyTilesSelectAllCheckBox.Name = "CopyTilesSelectAllCheckBox"
        Me.CopyTilesSelectAllCheckBox.Size = New System.Drawing.Size(83, 20)
        Me.CopyTilesSelectAllCheckBox.TabIndex = 5
        Me.CopyTilesSelectAllCheckBox.Text = "Select All"
        Me.CopyTilesSelectAllCheckBox.UseVisualStyleBackColor = True
        '
        'CopyTilesDataGridView
        '
        Me.CopyTilesDataGridView.AllowUserToAddRows = False
        Me.CopyTilesDataGridView.AllowUserToDeleteRows = False
        Me.CopyTilesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CopyTilesDataGridView.Location = New System.Drawing.Point(9, 130)
        Me.CopyTilesDataGridView.Name = "CopyTilesDataGridView"
        Me.CopyTilesDataGridView.Size = New System.Drawing.Size(743, 429)
        Me.CopyTilesDataGridView.TabIndex = 6
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(6, 111)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(87, 16)
        Me.Label22.TabIndex = 11
        Me.Label22.Text = "Tiles to Copy"
        '
        'CopyTilesLogCheckBox
        '
        Me.CopyTilesLogCheckBox.AutoSize = True
        Me.CopyTilesLogCheckBox.Location = New System.Drawing.Point(129, 83)
        Me.CopyTilesLogCheckBox.Name = "CopyTilesLogCheckBox"
        Me.CopyTilesLogCheckBox.Size = New System.Drawing.Size(199, 20)
        Me.CopyTilesLogCheckBox.TabIndex = 4
        Me.CopyTilesLogCheckBox.Text = "Send output to CopyTiles.log"
        Me.CopyTilesLogCheckBox.UseVisualStyleBackColor = True
        '
        'CopyTilesSourceTextBox
        '
        Me.CopyTilesSourceTextBox.Location = New System.Drawing.Point(129, 23)
        Me.CopyTilesSourceTextBox.Name = "CopyTilesSourceTextBox"
        Me.CopyTilesSourceTextBox.Size = New System.Drawing.Size(523, 22)
        Me.CopyTilesSourceTextBox.TabIndex = 0
        '
        'CopyTilesDestinationTextBox
        '
        Me.CopyTilesDestinationTextBox.Location = New System.Drawing.Point(129, 55)
        Me.CopyTilesDestinationTextBox.Name = "CopyTilesDestinationTextBox"
        Me.CopyTilesDestinationTextBox.Size = New System.Drawing.Size(523, 22)
        Me.CopyTilesDestinationTextBox.TabIndex = 2
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 58)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(117, 16)
        Me.Label23.TabIndex = 4
        Me.Label23.Text = "Destination Folder"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(30, 26)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(93, 16)
        Me.Label24.TabIndex = 3
        Me.Label24.Text = "Source Folder"
        '
        'CopyTilesStartButton
        '
        Me.CopyTilesStartButton.Location = New System.Drawing.Point(658, 85)
        Me.CopyTilesStartButton.Name = "CopyTilesStartButton"
        Me.CopyTilesStartButton.Size = New System.Drawing.Size(94, 26)
        Me.CopyTilesStartButton.TabIndex = 7
        Me.CopyTilesStartButton.Text = "Start"
        Me.CopyTilesStartButton.UseVisualStyleBackColor = True
        '
        'CopyTilesDestinationBrowseButton
        '
        Me.CopyTilesDestinationBrowseButton.Location = New System.Drawing.Point(658, 53)
        Me.CopyTilesDestinationBrowseButton.Name = "CopyTilesDestinationBrowseButton"
        Me.CopyTilesDestinationBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.CopyTilesDestinationBrowseButton.TabIndex = 3
        Me.CopyTilesDestinationBrowseButton.Text = "Browse"
        Me.CopyTilesDestinationBrowseButton.UseVisualStyleBackColor = True
        '
        'CopyTilesSourceBrowseButton
        '
        Me.CopyTilesSourceBrowseButton.Location = New System.Drawing.Point(658, 21)
        Me.CopyTilesSourceBrowseButton.Name = "CopyTilesSourceBrowseButton"
        Me.CopyTilesSourceBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.CopyTilesSourceBrowseButton.TabIndex = 1
        Me.CopyTilesSourceBrowseButton.Text = "Browse"
        Me.CopyTilesSourceBrowseButton.UseVisualStyleBackColor = True
        '
        'MapDetailsGroupBox
        '
        Me.MapDetailsGroupBox.Controls.Add(Me.MapDetailsSelectAllCheckBox)
        Me.MapDetailsGroupBox.Controls.Add(Me.MapDetailsLogCheckBox)
        Me.MapDetailsGroupBox.Controls.Add(Me.MapDetailsStartButton)
        Me.MapDetailsGroupBox.Controls.Add(Me.MapDetailsSelectNoneButton)
        Me.MapDetailsGroupBox.Controls.Add(Me.MapDetailsSelectAllButton)
        Me.MapDetailsGroupBox.Controls.Add(Me.Label25)
        Me.MapDetailsGroupBox.Controls.Add(Me.MapDetailsCheckedListBox)
        Me.MapDetailsGroupBox.Controls.Add(Me.Label27)
        Me.MapDetailsGroupBox.Controls.Add(Me.MapDetailsSourceTextBox)
        Me.MapDetailsGroupBox.Controls.Add(Me.MapDetailsBrowseButton)
        Me.MapDetailsGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.MapDetailsGroupBox.Name = "MapDetailsGroupBox"
        Me.MapDetailsGroupBox.Size = New System.Drawing.Size(758, 565)
        Me.MapDetailsGroupBox.TabIndex = 8
        Me.MapDetailsGroupBox.TabStop = False
        Me.MapDetailsGroupBox.Text = "Map Details"
        Me.MapDetailsGroupBox.Visible = False
        '
        'MapDetailsSelectAllCheckBox
        '
        Me.MapDetailsSelectAllCheckBox.AutoSize = True
        Me.MapDetailsSelectAllCheckBox.Location = New System.Drawing.Point(317, 51)
        Me.MapDetailsSelectAllCheckBox.Name = "MapDetailsSelectAllCheckBox"
        Me.MapDetailsSelectAllCheckBox.Size = New System.Drawing.Size(83, 20)
        Me.MapDetailsSelectAllCheckBox.TabIndex = 3
        Me.MapDetailsSelectAllCheckBox.Text = "Select All"
        Me.MapDetailsSelectAllCheckBox.UseVisualStyleBackColor = True
        '
        'MapDetailsLogCheckBox
        '
        Me.MapDetailsLogCheckBox.AutoSize = True
        Me.MapDetailsLogCheckBox.Location = New System.Drawing.Point(105, 51)
        Me.MapDetailsLogCheckBox.Name = "MapDetailsLogCheckBox"
        Me.MapDetailsLogCheckBox.Size = New System.Drawing.Size(206, 20)
        Me.MapDetailsLogCheckBox.TabIndex = 2
        Me.MapDetailsLogCheckBox.Text = "Send output to MapDetails.log"
        Me.MapDetailsLogCheckBox.UseVisualStyleBackColor = True
        '
        'MapDetailsStartButton
        '
        Me.MapDetailsStartButton.Location = New System.Drawing.Point(658, 194)
        Me.MapDetailsStartButton.Name = "MapDetailsStartButton"
        Me.MapDetailsStartButton.Size = New System.Drawing.Size(94, 26)
        Me.MapDetailsStartButton.TabIndex = 7
        Me.MapDetailsStartButton.Text = "Start"
        Me.MapDetailsStartButton.UseVisualStyleBackColor = True
        '
        'MapDetailsSelectNoneButton
        '
        Me.MapDetailsSelectNoneButton.Location = New System.Drawing.Point(658, 162)
        Me.MapDetailsSelectNoneButton.Name = "MapDetailsSelectNoneButton"
        Me.MapDetailsSelectNoneButton.Size = New System.Drawing.Size(94, 26)
        Me.MapDetailsSelectNoneButton.TabIndex = 6
        Me.MapDetailsSelectNoneButton.Text = "Select None"
        Me.MapDetailsSelectNoneButton.UseVisualStyleBackColor = True
        '
        'MapDetailsSelectAllButton
        '
        Me.MapDetailsSelectAllButton.Location = New System.Drawing.Point(658, 130)
        Me.MapDetailsSelectAllButton.Name = "MapDetailsSelectAllButton"
        Me.MapDetailsSelectAllButton.Size = New System.Drawing.Size(94, 26)
        Me.MapDetailsSelectAllButton.TabIndex = 5
        Me.MapDetailsSelectAllButton.Text = "Select All"
        Me.MapDetailsSelectAllButton.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(6, 111)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(67, 16)
        Me.Label25.TabIndex = 6
        Me.Label25.Text = "Map Files"
        '
        'MapDetailsCheckedListBox
        '
        Me.MapDetailsCheckedListBox.CheckOnClick = True
        Me.MapDetailsCheckedListBox.FormattingEnabled = True
        Me.MapDetailsCheckedListBox.Location = New System.Drawing.Point(6, 130)
        Me.MapDetailsCheckedListBox.Name = "MapDetailsCheckedListBox"
        Me.MapDetailsCheckedListBox.Size = New System.Drawing.Size(646, 429)
        Me.MapDetailsCheckedListBox.TabIndex = 4
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(6, 26)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(93, 16)
        Me.Label27.TabIndex = 2
        Me.Label27.Text = "Source Folder"
        '
        'MapDetailsSourceTextBox
        '
        Me.MapDetailsSourceTextBox.Location = New System.Drawing.Point(105, 23)
        Me.MapDetailsSourceTextBox.Name = "MapDetailsSourceTextBox"
        Me.MapDetailsSourceTextBox.Size = New System.Drawing.Size(547, 22)
        Me.MapDetailsSourceTextBox.TabIndex = 0
        '
        'MapDetailsBrowseButton
        '
        Me.MapDetailsBrowseButton.Location = New System.Drawing.Point(658, 21)
        Me.MapDetailsBrowseButton.Name = "MapDetailsBrowseButton"
        Me.MapDetailsBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.MapDetailsBrowseButton.TabIndex = 1
        Me.MapDetailsBrowseButton.Text = "Browse"
        Me.MapDetailsBrowseButton.UseVisualStyleBackColor = True
        '
        'DataFilesGroupBox
        '
        Me.DataFilesGroupBox.Controls.Add(Me.DataFilesDataGridView)
        Me.DataFilesGroupBox.Controls.Add(Me.DataFilesLogCheckBox)
        Me.DataFilesGroupBox.Controls.Add(Me.DataFilesSourceTextBox)
        Me.DataFilesGroupBox.Controls.Add(Me.Label29)
        Me.DataFilesGroupBox.Controls.Add(Me.DataFilesStartButton)
        Me.DataFilesGroupBox.Controls.Add(Me.DataFilesSourceBrowseButton)
        Me.DataFilesGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.DataFilesGroupBox.Name = "DataFilesGroupBox"
        Me.DataFilesGroupBox.Size = New System.Drawing.Size(956, 565)
        Me.DataFilesGroupBox.TabIndex = 13
        Me.DataFilesGroupBox.TabStop = False
        Me.DataFilesGroupBox.Text = "Data Files"
        Me.DataFilesGroupBox.Visible = False
        '
        'DataFilesDataGridView
        '
        Me.DataFilesDataGridView.AllowUserToAddRows = False
        Me.DataFilesDataGridView.AllowUserToDeleteRows = False
        Me.DataFilesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataFilesDataGridView.Location = New System.Drawing.Point(6, 85)
        Me.DataFilesDataGridView.Name = "DataFilesDataGridView"
        Me.DataFilesDataGridView.Size = New System.Drawing.Size(944, 474)
        Me.DataFilesDataGridView.TabIndex = 3
        '
        'DataFilesLogCheckBox
        '
        Me.DataFilesLogCheckBox.AutoSize = True
        Me.DataFilesLogCheckBox.Location = New System.Drawing.Point(102, 51)
        Me.DataFilesLogCheckBox.Name = "DataFilesLogCheckBox"
        Me.DataFilesLogCheckBox.Size = New System.Drawing.Size(195, 20)
        Me.DataFilesLogCheckBox.TabIndex = 2
        Me.DataFilesLogCheckBox.Text = "Send output to DataFiles.log"
        Me.DataFilesLogCheckBox.UseVisualStyleBackColor = True
        '
        'DataFilesSourceTextBox
        '
        Me.DataFilesSourceTextBox.Location = New System.Drawing.Point(102, 23)
        Me.DataFilesSourceTextBox.Name = "DataFilesSourceTextBox"
        Me.DataFilesSourceTextBox.Size = New System.Drawing.Size(748, 22)
        Me.DataFilesSourceTextBox.TabIndex = 0
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(3, 26)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(93, 16)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "Source Folder"
        '
        'DataFilesStartButton
        '
        Me.DataFilesStartButton.Location = New System.Drawing.Point(856, 53)
        Me.DataFilesStartButton.Name = "DataFilesStartButton"
        Me.DataFilesStartButton.Size = New System.Drawing.Size(94, 26)
        Me.DataFilesStartButton.TabIndex = 4
        Me.DataFilesStartButton.Text = "Start"
        Me.DataFilesStartButton.UseVisualStyleBackColor = True
        '
        'DataFilesSourceBrowseButton
        '
        Me.DataFilesSourceBrowseButton.Location = New System.Drawing.Point(856, 21)
        Me.DataFilesSourceBrowseButton.Name = "DataFilesSourceBrowseButton"
        Me.DataFilesSourceBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.DataFilesSourceBrowseButton.TabIndex = 1
        Me.DataFilesSourceBrowseButton.Text = "Browse"
        Me.DataFilesSourceBrowseButton.UseVisualStyleBackColor = True
        '
        'ColorThemeApplyGroupBox
        '
        Me.ColorThemeApplyGroupBox.Controls.Add(Me.ApplyColorThemeBackupPalettesCheckBox)
        Me.ColorThemeApplyGroupBox.Controls.Add(Me.ApplyColorThemeMapListBox)
        Me.ColorThemeApplyGroupBox.Controls.Add(Me.ApplyColorThemeColorThemeListBox)
        Me.ColorThemeApplyGroupBox.Controls.Add(Me.ApplyColorThemeStartButton)
        Me.ColorThemeApplyGroupBox.Controls.Add(Me.ApplyColorThemeColorThemeFolderTextBox)
        Me.ColorThemeApplyGroupBox.Controls.Add(Me.ApplyColorThemeMapFolderTextBox)
        Me.ColorThemeApplyGroupBox.Controls.Add(Me.ApplyColorThemeMapFolderBrowseButton)
        Me.ColorThemeApplyGroupBox.Controls.Add(Me.ApplyColorThemeColorThemeFolderBrowseButton)
        Me.ColorThemeApplyGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.ColorThemeApplyGroupBox.Name = "ColorThemeApplyGroupBox"
        Me.ColorThemeApplyGroupBox.Size = New System.Drawing.Size(956, 565)
        Me.ColorThemeApplyGroupBox.TabIndex = 12
        Me.ColorThemeApplyGroupBox.TabStop = False
        Me.ColorThemeApplyGroupBox.Text = "Apply Color Theme"
        Me.ColorThemeApplyGroupBox.Visible = False
        '
        'ApplyColorThemeBackupPalettesCheckBox
        '
        Me.ApplyColorThemeBackupPalettesCheckBox.AutoSize = True
        Me.ApplyColorThemeBackupPalettesCheckBox.Checked = True
        Me.ApplyColorThemeBackupPalettesCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ApplyColorThemeBackupPalettesCheckBox.Location = New System.Drawing.Point(581, 53)
        Me.ApplyColorThemeBackupPalettesCheckBox.Name = "ApplyColorThemeBackupPalettesCheckBox"
        Me.ApplyColorThemeBackupPalettesCheckBox.Size = New System.Drawing.Size(259, 20)
        Me.ApplyColorThemeBackupPalettesCheckBox.TabIndex = 7
        Me.ApplyColorThemeBackupPalettesCheckBox.Text = "Backup original palettes before saving."
        Me.ApplyColorThemeBackupPalettesCheckBox.UseVisualStyleBackColor = True
        '
        'ApplyColorThemeMapListBox
        '
        Me.ApplyColorThemeMapListBox.FormattingEnabled = True
        Me.ApplyColorThemeMapListBox.ItemHeight = 16
        Me.ApplyColorThemeMapListBox.Location = New System.Drawing.Point(481, 81)
        Me.ApplyColorThemeMapListBox.Name = "ApplyColorThemeMapListBox"
        Me.ApplyColorThemeMapListBox.Size = New System.Drawing.Size(469, 420)
        Me.ApplyColorThemeMapListBox.TabIndex = 5
        '
        'ApplyColorThemeColorThemeListBox
        '
        Me.ApplyColorThemeColorThemeListBox.FormattingEnabled = True
        Me.ApplyColorThemeColorThemeListBox.ItemHeight = 16
        Me.ApplyColorThemeColorThemeListBox.Location = New System.Drawing.Point(6, 81)
        Me.ApplyColorThemeColorThemeListBox.Name = "ApplyColorThemeColorThemeListBox"
        Me.ApplyColorThemeColorThemeListBox.Size = New System.Drawing.Size(469, 420)
        Me.ApplyColorThemeColorThemeListBox.TabIndex = 2
        '
        'ApplyColorThemeStartButton
        '
        Me.ApplyColorThemeStartButton.Location = New System.Drawing.Point(6, 507)
        Me.ApplyColorThemeStartButton.Name = "ApplyColorThemeStartButton"
        Me.ApplyColorThemeStartButton.Size = New System.Drawing.Size(944, 52)
        Me.ApplyColorThemeStartButton.TabIndex = 6
        Me.ApplyColorThemeStartButton.Text = "Start"
        Me.ApplyColorThemeStartButton.UseVisualStyleBackColor = True
        '
        'ApplyColorThemeColorThemeFolderTextBox
        '
        Me.ApplyColorThemeColorThemeFolderTextBox.Location = New System.Drawing.Point(166, 23)
        Me.ApplyColorThemeColorThemeFolderTextBox.Name = "ApplyColorThemeColorThemeFolderTextBox"
        Me.ApplyColorThemeColorThemeFolderTextBox.Size = New System.Drawing.Size(309, 22)
        Me.ApplyColorThemeColorThemeFolderTextBox.TabIndex = 1
        '
        'ApplyColorThemeMapFolderTextBox
        '
        Me.ApplyColorThemeMapFolderTextBox.Location = New System.Drawing.Point(581, 23)
        Me.ApplyColorThemeMapFolderTextBox.Name = "ApplyColorThemeMapFolderTextBox"
        Me.ApplyColorThemeMapFolderTextBox.Size = New System.Drawing.Size(369, 22)
        Me.ApplyColorThemeMapFolderTextBox.TabIndex = 4
        '
        'ApplyColorThemeMapFolderBrowseButton
        '
        Me.ApplyColorThemeMapFolderBrowseButton.Location = New System.Drawing.Point(481, 21)
        Me.ApplyColorThemeMapFolderBrowseButton.Name = "ApplyColorThemeMapFolderBrowseButton"
        Me.ApplyColorThemeMapFolderBrowseButton.Size = New System.Drawing.Size(94, 26)
        Me.ApplyColorThemeMapFolderBrowseButton.TabIndex = 3
        Me.ApplyColorThemeMapFolderBrowseButton.Text = "Map Folder"
        Me.ApplyColorThemeMapFolderBrowseButton.UseVisualStyleBackColor = True
        '
        'ApplyColorThemeColorThemeFolderBrowseButton
        '
        Me.ApplyColorThemeColorThemeFolderBrowseButton.Location = New System.Drawing.Point(6, 21)
        Me.ApplyColorThemeColorThemeFolderBrowseButton.Name = "ApplyColorThemeColorThemeFolderBrowseButton"
        Me.ApplyColorThemeColorThemeFolderBrowseButton.Size = New System.Drawing.Size(154, 26)
        Me.ApplyColorThemeColorThemeFolderBrowseButton.TabIndex = 0
        Me.ApplyColorThemeColorThemeFolderBrowseButton.Text = "Color Theme Folder"
        Me.ApplyColorThemeColorThemeFolderBrowseButton.UseVisualStyleBackColor = True
        '
        'ColorThemeCreateGroupBox
        '
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.CreateColorThemeIncludeNonPaletteColorsCheckBox)
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.CreateColorThemeIncludeAllCustomColorsCheckBox)
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.CreateColorThemeStartButton)
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.Label26)
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.CreateColorThemeSourceMapTextBox)
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.CreateColorThemeColorThemeTextBox)
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.Label28)
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.CreateColorThemeSaveButton)
        Me.ColorThemeCreateGroupBox.Controls.Add(Me.CreateColorThemeSourceMapOpenButton)
        Me.ColorThemeCreateGroupBox.Location = New System.Drawing.Point(12, 33)
        Me.ColorThemeCreateGroupBox.Name = "ColorThemeCreateGroupBox"
        Me.ColorThemeCreateGroupBox.Size = New System.Drawing.Size(758, 117)
        Me.ColorThemeCreateGroupBox.TabIndex = 11
        Me.ColorThemeCreateGroupBox.TabStop = False
        Me.ColorThemeCreateGroupBox.Text = "Create Color Theme"
        Me.ColorThemeCreateGroupBox.Visible = False
        '
        'CreateColorThemeIncludeNonPaletteColorsCheckBox
        '
        Me.CreateColorThemeIncludeNonPaletteColorsCheckBox.AutoSize = True
        Me.CreateColorThemeIncludeNonPaletteColorsCheckBox.Location = New System.Drawing.Point(280, 83)
        Me.CreateColorThemeIncludeNonPaletteColorsCheckBox.Name = "CreateColorThemeIncludeNonPaletteColorsCheckBox"
        Me.CreateColorThemeIncludeNonPaletteColorsCheckBox.Size = New System.Drawing.Size(183, 20)
        Me.CreateColorThemeIncludeNonPaletteColorsCheckBox.TabIndex = 7
        Me.CreateColorThemeIncludeNonPaletteColorsCheckBox.Text = "Include non-palette colors."
        Me.CreateColorThemeIncludeNonPaletteColorsCheckBox.UseVisualStyleBackColor = True
        '
        'CreateColorThemeIncludeAllCustomColorsCheckBox
        '
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.AutoSize = True
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.Checked = True
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.Location = New System.Drawing.Point(98, 83)
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.Name = "CreateColorThemeIncludeAllCustomColorsCheckBox"
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.Size = New System.Drawing.Size(176, 20)
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.TabIndex = 6
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.Text = "Include all custom colors."
        Me.CreateColorThemeIncludeAllCustomColorsCheckBox.UseVisualStyleBackColor = True
        '
        'CreateColorThemeStartButton
        '
        Me.CreateColorThemeStartButton.Location = New System.Drawing.Point(658, 85)
        Me.CreateColorThemeStartButton.Name = "CreateColorThemeStartButton"
        Me.CreateColorThemeStartButton.Size = New System.Drawing.Size(94, 26)
        Me.CreateColorThemeStartButton.TabIndex = 4
        Me.CreateColorThemeStartButton.Text = "Start"
        Me.CreateColorThemeStartButton.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(11, 26)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(81, 16)
        Me.Label26.TabIndex = 5
        Me.Label26.Text = "Source Map"
        '
        'CreateColorThemeSourceMapTextBox
        '
        Me.CreateColorThemeSourceMapTextBox.Location = New System.Drawing.Point(98, 23)
        Me.CreateColorThemeSourceMapTextBox.Name = "CreateColorThemeSourceMapTextBox"
        Me.CreateColorThemeSourceMapTextBox.Size = New System.Drawing.Size(554, 22)
        Me.CreateColorThemeSourceMapTextBox.TabIndex = 0
        '
        'CreateColorThemeColorThemeTextBox
        '
        Me.CreateColorThemeColorThemeTextBox.Location = New System.Drawing.Point(98, 55)
        Me.CreateColorThemeColorThemeTextBox.Name = "CreateColorThemeColorThemeTextBox"
        Me.CreateColorThemeColorThemeTextBox.Size = New System.Drawing.Size(554, 22)
        Me.CreateColorThemeColorThemeTextBox.TabIndex = 2
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(6, 58)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(86, 16)
        Me.Label28.TabIndex = 2
        Me.Label28.Text = "Color Theme"
        '
        'CreateColorThemeSaveButton
        '
        Me.CreateColorThemeSaveButton.Location = New System.Drawing.Point(658, 53)
        Me.CreateColorThemeSaveButton.Name = "CreateColorThemeSaveButton"
        Me.CreateColorThemeSaveButton.Size = New System.Drawing.Size(94, 26)
        Me.CreateColorThemeSaveButton.TabIndex = 3
        Me.CreateColorThemeSaveButton.Text = "Save"
        Me.CreateColorThemeSaveButton.UseVisualStyleBackColor = True
        '
        'CreateColorThemeSourceMapOpenButton
        '
        Me.CreateColorThemeSourceMapOpenButton.Location = New System.Drawing.Point(658, 21)
        Me.CreateColorThemeSourceMapOpenButton.Name = "CreateColorThemeSourceMapOpenButton"
        Me.CreateColorThemeSourceMapOpenButton.Size = New System.Drawing.Size(94, 26)
        Me.CreateColorThemeSourceMapOpenButton.TabIndex = 1
        Me.CreateColorThemeSourceMapOpenButton.Text = "Open"
        Me.CreateColorThemeSourceMapOpenButton.UseVisualStyleBackColor = True
        '
        'CreateColorThemeOpenFileDialog
        '
        Me.CreateColorThemeOpenFileDialog.FileName = "OpenFileDialog1"
        '
        'DDToolsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1012, 624)
        Me.Controls.Add(Me.MainMenuStrip)
        Me.Controls.Add(Me.DataFilesGroupBox)
        Me.Controls.Add(Me.CopyTilesGroupBox)
        Me.Controls.Add(Me.CopyAssetsGroupBox)
        Me.Controls.Add(Me.ColorThemeApplyGroupBox)
        Me.Controls.Add(Me.ColorThemeCreateGroupBox)
        Me.Controls.Add(Me.UnpackAssetsGroupBox)
        Me.Controls.Add(Me.ConvertPacksGroupBox)
        Me.Controls.Add(Me.MapDetailsGroupBox)
        Me.Controls.Add(Me.TagAssetsGroupBox)
        Me.Controls.Add(Me.ConvertAssetsGroupBox)
        Me.Controls.Add(Me.PackAssetsGroupBox)
        Me.Controls.Add(Me.TitlePanel)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "DDToolsForm"
        Me.Text = "EightBitz's Dungeondraft Tools"
        Me.MainMenuStrip.ResumeLayout(False)
        Me.MainMenuStrip.PerformLayout()
        Me.ConvertPacksGroupBox.ResumeLayout(False)
        Me.ConvertPacksGroupBox.PerformLayout()
        Me.TagAssetsGroupBox.ResumeLayout(False)
        Me.TagAssetsGroupBox.PerformLayout()
        Me.CopyAssetsGroupBox.ResumeLayout(False)
        Me.CopyAssetsGroupBox.PerformLayout()
        Me.ConvertAssetsGroupBox.ResumeLayout(False)
        Me.ConvertAssetsGroupBox.PerformLayout()
        Me.TitlePanel.ResumeLayout(False)
        Me.TitlePanel.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UnpackAssetsGroupBox.ResumeLayout(False)
        Me.UnpackAssetsGroupBox.PerformLayout()
        Me.PackAssetsGroupBox.ResumeLayout(False)
        Me.PackAssetsGroupBox.PerformLayout()
        CType(Me.PackAssetsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CopyTilesGroupBox.ResumeLayout(False)
        Me.CopyTilesGroupBox.PerformLayout()
        CType(Me.CopyTilesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MapDetailsGroupBox.ResumeLayout(False)
        Me.MapDetailsGroupBox.PerformLayout()
        Me.DataFilesGroupBox.ResumeLayout(False)
        Me.DataFilesGroupBox.PerformLayout()
        CType(Me.DataFilesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ColorThemeApplyGroupBox.ResumeLayout(False)
        Me.ColorThemeApplyGroupBox.PerformLayout()
        Me.ColorThemeCreateGroupBox.ResumeLayout(False)
        Me.ColorThemeCreateGroupBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MainMenuStrip As MenuStrip
    Friend WithEvents MainMenuToolStripMenu As ToolStripMenuItem
    Friend WithEvents ConvertAssetsMenuItem As ToolStripMenuItem
    Friend WithEvents ConvertPacksMenuItem As ToolStripMenuItem
    Friend WithEvents CopyAssetsMenuItem As ToolStripMenuItem
    Friend WithEvents TagAssetsMenuItem As ToolStripMenuItem
    Friend WithEvents ConvertPacksGroupBox As GroupBox
    Friend WithEvents ConvertPacksDestinationBrowseButton As Button
    Friend WithEvents ConvertPacksSourceBrowseButton As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents ConvertPacksDestinationTextBox As TextBox
    Friend WithEvents ConvertPacksSourceTextBox As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ConvertPacksCheckedListBox As CheckedListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents ConvertPacksCleanUpCheckBox As CheckBox
    Friend WithEvents ConvertPacksStartButton As Button
    Friend WithEvents ConvertPacksSelectNoneButton As Button
    Friend WithEvents ConvertPacksSelectAllButton As Button
    Friend WithEvents ConvertPacksSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents ConvertPacksDestinationBrowserDialog As FolderBrowserDialog
    Friend WithEvents TagAssetsGroupBox As GroupBox
    Friend WithEvents TagAssetsStartButton As Button
    Friend WithEvents TagAssetsSelectNoneButton As Button
    Friend WithEvents TagAssetsSelectAllButton As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents TagAssetsCheckedListBox As CheckedListBox
    Friend WithEvents TagAssetsDefaultTagTextBox As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TagAssetsSourceTextBox As TextBox
    Friend WithEvents TagAssetsBrowseButton As Button
    Friend WithEvents TagAssetsSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents CopyAssetsGroupBox As GroupBox
    Friend WithEvents CopyAssetsStartButton As Button
    Friend WithEvents CopyAssetsDestinationBrowseButton As Button
    Friend WithEvents CopyAssetsSourceBrowseButton As Button
    Friend WithEvents CopyAssetsPortalsCheckBox As CheckBox
    Friend WithEvents CopyAssetsCreateTagsCheckBox As CheckBox
    Friend WithEvents CopyAssetsSourceTextBox As TextBox
    Friend WithEvents CopyAssetsDestinationTextBox As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents CopyAssetsSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents CopyAssetsDestinationBrowserDialog As FolderBrowserDialog
    Friend WithEvents ConvertAssetsGroupBox As GroupBox
    Friend WithEvents Label10 As Label
    Friend WithEvents ConvertAssetsSourceTextBox As TextBox
    Friend WithEvents ConvertAssetsDestinationTextBox As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents ConvertAssetsStartButton As Button
    Friend WithEvents ConvertAssetsDestinationBrowseButton As Button
    Friend WithEvents ConvertAssetsSourceBrowseButton As Button
    Friend WithEvents ConvertAssetsSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents ConvertAssetsDestinationBrowserDialog As FolderBrowserDialog
    Friend WithEvents ConvertPacksLogCheckBox As CheckBox
    Friend WithEvents TagAssetsLogCheckBox As CheckBox
    Friend WithEvents CopyAssetsLogCheckBox As CheckBox
    Friend WithEvents ConvertAssetsLogCheckBox As CheckBox
    Friend WithEvents TitlePanel As Panel
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents UnpackAssetsMenuItem As ToolStripMenuItem
    Friend WithEvents UnpackAssetsGroupBox As GroupBox
    Friend WithEvents UnpackAssetsStartButton As Button
    Friend WithEvents UnpackAssetsSelectNoneButton As Button
    Friend WithEvents UnpackAssetsSelectAllButton As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents UnpackAssetsCheckedListBox As CheckedListBox
    Friend WithEvents Label15 As Label
    Friend WithEvents UnpackAssetsSourceTextBox As TextBox
    Friend WithEvents UnpackAssetsDestinationTextBox As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents UnpackAssetsDestinationBrowseButton As Button
    Friend WithEvents UnpackAssetsSourceBrowseButton As Button
    Friend WithEvents UnpackAssetsSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents UnpackAssetsDestinationBrowserDialog As FolderBrowserDialog
    Friend WithEvents PackAssetsMenuItem As ToolStripMenuItem
    Friend WithEvents PackAssetsSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents PackAssetsDestinationBrowserDialog As FolderBrowserDialog
    Friend WithEvents PackAssetsGroupBox As GroupBox
    Friend WithEvents PackAssetsStartButton As Button
    Friend WithEvents PackAssetsSelectNoneButton As Button
    Friend WithEvents PackAssetsSelectAllButton As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents PackAssetsSourceTextBox As TextBox
    Friend WithEvents PackAssetsDestinationTextBox As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents PackAssetsDestinationBrowseButton As Button
    Friend WithEvents PackAssetsSourceBrowseButton As Button
    Friend WithEvents CopyAssetsSelectNoneButton As Button
    Friend WithEvents CopyAssetsSelectAllButton As Button
    Friend WithEvents CopyAssetsCheckedListBox As CheckedListBox
    Friend WithEvents ConvertAssetsSelectNoneButton As Button
    Friend WithEvents ConvertAssetsSelectAllButton As Button
    Friend WithEvents ConvertAssetsCheckedListBox As CheckedListBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents CopyTilesMenuItem As ToolStripMenuItem
    Friend WithEvents CopyTilesGroupBox As GroupBox
    Friend WithEvents CopyTilesDataGridView As DataGridView
    Friend WithEvents Label22 As Label
    Friend WithEvents CopyTilesLogCheckBox As CheckBox
    Friend WithEvents CopyTilesSourceTextBox As TextBox
    Friend WithEvents CopyTilesDestinationTextBox As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents CopyTilesStartButton As Button
    Friend WithEvents CopyTilesDestinationBrowseButton As Button
    Friend WithEvents CopyTilesSourceBrowseButton As Button
    Friend WithEvents CopyTilesSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents CopyTilesDestinationBrowserDialog As FolderBrowserDialog
    Friend WithEvents PackAssetsDataGridView As DataGridView
    Friend WithEvents MapDetailsMenuItem As ToolStripMenuItem
    Friend WithEvents MapDetailsLogCheckBox As CheckBox
    Friend WithEvents MapDetailsStartButton As Button
    Friend WithEvents MapDetailsSelectNoneButton As Button
    Friend WithEvents MapDetailsSelectAllButton As Button
    Friend WithEvents Label25 As Label
    Friend WithEvents MapDetailsCheckedListBox As CheckedListBox
    Friend WithEvents Label27 As Label
    Friend WithEvents MapDetailsSourceTextBox As TextBox
    Friend WithEvents MapDetailsBrowseButton As Button
    Friend WithEvents MapDetailsGroupBox As GroupBox
    Friend WithEvents MapDetailsSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents PackAssetsLogCheckBox As CheckBox
    Friend WithEvents PackAssetsOverwriteCheckBox As CheckBox
    Friend WithEvents PackAssetsRefreshButton As Button
    Friend WithEvents PreferencesToolStripMenu As ToolStripMenuItem
    Friend WithEvents LoadPrefsMenuItem As ToolStripMenuItem
    Friend WithEvents SavePrefsMenuItem As ToolStripMenuItem
    Friend WithEvents UnpackAssetsLogCheckBox As CheckBox
    Friend WithEvents ConvertPacksSelectAllCheckBox As CheckBox
    Friend WithEvents TagAssetsSelectAllCheckBox As CheckBox
    Friend WithEvents CopyAssetsSelectAllCheckBox As CheckBox
    Friend WithEvents ConvertAssetsSelectAllCheckBox As CheckBox
    Friend WithEvents UnpackAssetsSelectAllCheckBox As CheckBox
    Friend WithEvents PackAssetsSelectAllCheckBox As CheckBox
    Friend WithEvents CopyTilesSelectAllCheckBox As CheckBox
    Friend WithEvents MapDetailsSelectAllCheckBox As CheckBox
    Friend WithEvents DataFilesGroupBox As GroupBox
    Friend WithEvents DataFilesDataGridView As DataGridView
    Friend WithEvents DataFilesLogCheckBox As CheckBox
    Friend WithEvents DataFilesSourceTextBox As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents DataFilesStartButton As Button
    Friend WithEvents DataFilesSourceBrowseButton As Button
    Friend WithEvents DataFilesSourceBrowserDialog As FolderBrowserDialog
    Friend WithEvents DataFilesMenuItem As ToolStripMenuItem
    Friend WithEvents DataFilesColorDialog As ColorDialog
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents VersionLabel As Label
    Friend WithEvents CreativeCommonsLinkLabel As LinkLabel
    Friend WithEvents GitHubLinkLabel As LinkLabel
    Friend WithEvents EmailLinkLabel As LinkLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DocumentationMenuItem As ToolStripMenuItem
    Friend WithEvents LicenseMenuItem As ToolStripMenuItem
    Friend WithEvents READMEMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ColorThemeApplyGroupBox As GroupBox
    Friend WithEvents ApplyColorThemeMapListBox As ListBox
    Friend WithEvents ApplyColorThemeColorThemeListBox As ListBox
    Friend WithEvents ApplyColorThemeStartButton As Button
    Friend WithEvents ApplyColorThemeColorThemeFolderTextBox As TextBox
    Friend WithEvents ApplyColorThemeMapFolderTextBox As TextBox
    Friend WithEvents ApplyColorThemeMapFolderBrowseButton As Button
    Friend WithEvents ApplyColorThemeColorThemeFolderBrowseButton As Button
    Friend WithEvents ColorThemeCreateGroupBox As GroupBox
    Friend WithEvents Label26 As Label
    Friend WithEvents CreateColorThemeSourceMapTextBox As TextBox
    Friend WithEvents CreateColorThemeColorThemeTextBox As TextBox
    Friend WithEvents Label28 As Label
    Friend WithEvents CreateColorThemeSaveButton As Button
    Friend WithEvents CreateColorThemeSourceMapOpenButton As Button
    Friend WithEvents CreateColorThemeOpenFileDialog As OpenFileDialog
    Friend WithEvents CreateColorThemeSaveFileDialog As SaveFileDialog
    Friend WithEvents ColorThemeMenuItem As ToolStripMenuItem
    Friend WithEvents ColorThemeCreateFromMapMenuItem As ToolStripMenuItem
    Friend WithEvents ColorThemeApplyToMapMenuItem As ToolStripMenuItem
    Friend WithEvents CreateColorThemeStartButton As Button
    Friend WithEvents ApplyColorThemeThemeFolderBrowserDialog As FolderBrowserDialog
    Friend WithEvents ApplyColorThemeMapFolderBrowserDialog As FolderBrowserDialog
    Friend WithEvents CreateColorThemeIncludeNonPaletteColorsCheckBox As CheckBox
    Friend WithEvents CreateColorThemeIncludeAllCustomColorsCheckBox As CheckBox
    Friend WithEvents ApplyColorThemeBackupPalettesCheckBox As CheckBox
End Class
