﻿Public Class OutputForm
    Private Sub OutputOKButton_Click(sender As Object, e As EventArgs) Handles OutputOKButton.Click
        Me.Hide()
    End Sub
End Class